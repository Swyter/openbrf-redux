#include "myselectionmodel.h"

//MySelectionModel::MySelectionModel(QObject *parent)
  //:QItemSelectionModel(parent)
//{
//}
