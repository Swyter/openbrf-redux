#ifndef DDSDATA_H
#define DDSDATA_H

typedef struct {
  unsigned int bind;
  int sx;
  int sy;
  int mipmap;
  int filesize;
  int ddxversion;
} DdsData;

#endif // DDSDATA_H
