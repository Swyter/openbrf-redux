<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AskBoneDialog</name>
    <message>
        <location filename="../askBoneDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="62"/>
        <source>Reference skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="78"/>
        <source>Bone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="99"/>
        <source>This mesh is not rigged:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="117"/>
        <source>Select a skeleton and a bone to attach this mesh to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="130"/>
        <source>at origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="143"/>
        <source>in the correct final position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="156"/>
        <source>Piece currently centered:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskCreaseDialog</name>
    <message>
        <location filename="../askCreaseDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="64"/>
        <source>Recomputing normals:
how many hard edges?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="83"/>
        <source>all edges soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="104"/>
        <source>all edges hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="120"/>
        <source>keep texture
seams hard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskFlagsDialog</name>
    <message>
        <location filename="../askFlagsDialog.cpp" line="39"/>
        <source>unused?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.cpp" line="47"/>
        <source>reserved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="20"/>
        <source>Flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="76"/>
        <source>show all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3594"/>
        <source>No fog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3595"/>
        <source>No Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3597"/>
        <source>No Z-write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3598"/>
        <source>No depth Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3599"/>
        <source>Specular enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3600"/>
        <source>Alpha test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3601"/>
        <source>Uniform lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3604"/>
        <source>Blend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3605"/>
        <source>Blend add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3606"/>
        <source>Blend multiply *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3607"/>
        <source>Blend factor **</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3608"/>
        <source>Alpha test 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3609"/>
        <source>Alpha test 128</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3610"/>
        <source>Alpha test 256 *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3613"/>
        <source>Render 1st</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3614"/>
        <source>Origin at camera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3615"/>
        <source>LoD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3626"/>
        <source>Invert bumpmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3437"/>
        <source>Two-sided (?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3438"/>
        <source>No Collision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3439"/>
        <source>No Shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3455"/>
        <source>Difficult (?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3456"/>
        <source>Unwalkable (?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3513"/>
        <location filename="../mainwindow.cpp" line="3515"/>
        <location filename="../mainwindow.cpp" line="3521"/>
        <location filename="../mainwindow.cpp" line="3539"/>
        <location filename="../mainwindow.cpp" line="3541"/>
        <source>Unknown (for particles?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3522"/>
        <source>Unknown (screen space?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3514"/>
        <source>Unknown (plants?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3517"/>
        <source>Unknown (hairs and body parts?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3530"/>
        <source>reserved (tangent space)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3531"/>
        <source>reserved (Warband format)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3512"/>
        <source>Unknown (for props?)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskIntervalDialog</name>
    <message>
        <location filename="../askIntervalDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="30"/>
        <location filename="../askIntervalDialog.ui" line="47"/>
        <source>0000009; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="37"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="54"/>
        <source>from:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="64"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="71"/>
        <source>select time interval:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskLodOptionsDialog</name>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="20"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;When OpenBRF computes a &lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;LOD (Level Of Detail) Pyramid&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt; for a mesh...&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="34"/>
        <source>which levels to build, and with how many faces (w.r.t. original mesh)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="40"/>
        <source>LOD1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="47"/>
        <source>LOD2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="54"/>
        <source>LOD3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="61"/>
        <source>LOD4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="103"/>
        <source>Build?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="113"/>
        <source>% faces:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="138"/>
        <source>Overwrite existing LOD Pyramid (if there is one?):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="144"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="151"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskModErrorDialog</name>
    <message>
        <location filename="../askModErrorDialog.cpp" line="35"/>
        <source>Look for:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="42"/>
        <source>Any kind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="52"/>
        <source>Searching for errors...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="54"/>
        <source>&lt;i&gt;scanning data...&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="90"/>
        <source>Found 0 errors in module!</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../askModErrorDialog.cpp" line="92"/>
        <source>Found %n%1 error:</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="106"/>
        <source>&lt;i&gt;[ready]&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="124"/>
        <source>More errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="130"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="145"/>
        <source>OpenBrf -- Module %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskNewUiPictureDialog</name>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="42"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;This will create: a Mesh, a Material, and a Texture&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;which can be used ingame as a 2D decoration &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;in the background of menus.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="61"/>
        <source>Size and Pos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="76"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="83"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="102"/>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="112"/>
        <source>Lower-left
corner: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="330"/>
        <source>Actual pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="130"/>
        <source>in pixels, on a
1024x768 sceen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="444"/>
        <source>replace existing Mat.
Mesh, and Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="123"/>
        <source>in % of screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="318"/>
        <source>Align:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="337"/>
        <source>Set fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="356"/>
        <source>Picture name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="368"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="392"/>
        <source>Overlay mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="404"/>
        <source>Darken (multiply)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="417"/>
        <source>Normal (alpha blend)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="430"/>
        <source>Substitute (no alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.cpp" line="159"/>
        <source>Select a texture for a menu background file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskSelectBRFDialog</name>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="31"/>
        <source>In
Module
folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="64"/>
        <source>Files not
included in
module.ini:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="81"/>
        <source>In
Comm Res
folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="98"/>
        <source>&lt;line_num&gt;.&lt;filename&gt; (&lt;#used&gt; + &lt;#unused&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="127"/>
        <source>Open module.ini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="134"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="141"/>
        <source>Count used</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskSkelDialog</name>
    <message>
        <location filename="../askSkelDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="42"/>
        <source>cbSkelTo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="65"/>
        <source>From (current skeleton):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="81"/>
        <source>To (destination skeleton):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="102"/>
        <source>Change geometry of meshes currently rigged for a skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="120"/>
        <source>to make it follow a new skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="133"/>
        <source>Put result in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="145"/>
        <source>same mesh (overwrite)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="158"/>
        <source>new mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="171"/>
        <source>new vertex-ani frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="185"/>
        <source>Method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="197"/>
        <source>generic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="210"/>
        <source>humanoids</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskTexturenameDialog</name>
    <message>
        <location filename="../askTexturenameDialog.cpp" line="17"/>
        <source>also add new %1(s) 
with the same name(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.cpp" line="71"/>
        <source>Select a texture file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskTransformDialog</name>
    <message>
        <location filename="../askTransformDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="42"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="120"/>
        <location filename="../askTransformDialog.ui" line="256"/>
        <location filename="../askTransformDialog.ui" line="398"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="136"/>
        <location filename="../askTransformDialog.ui" line="272"/>
        <location filename="../askTransformDialog.ui" line="414"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="152"/>
        <location filename="../askTransformDialog.ui" line="288"/>
        <location filename="../askTransformDialog.ui" line="430"/>
        <source>Z:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="169"/>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="305"/>
        <source>Scale %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="446"/>
        <source>Uniform</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskUnrefTextureDialog</name>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="25"/>
        <source>Unused DDS files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="40"/>
        <source>Note: these are the files which are not included
 in any BRF file as textures.
They will not be even loaded by the game.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="68"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="14"/>
        <source>Tune Per-Vertex Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="42"/>
        <source>Hue:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="58"/>
        <source>Saturation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="74"/>
        <source>Brightness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="190"/>
        <source>Contrast:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GLWidget</name>
    <message>
        <location filename="../glwidgets.cpp" line="1047"/>
        <source>Scene mode: navigate with mouse and WASD (levitate with wheel, zoom in with shift)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1052"/>
        <source>Helmet mode: for objects with vertical Z axis, like M&amp;B helmets or weapons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1054"/>
        <source>Default mode: rotate objects with mouse, zoom in/out with wheel.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GuiPanel</name>
    <message>
        <location filename="../guipanel.cpp" line="134"/>
        <location filename="../guipanel.cpp" line="145"/>
        <source>unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="135"/>
        <source>not-found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="136"/>
        <source>common</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="137"/>
        <source>module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="138"/>
        <source>local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="142"/>
        <source>DXT 1 (1bit alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="143"/>
        <source>DXT 3 (sharp alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="144"/>
        <source>DXT 5 (smooth alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="285"/>
        <source>Mesh-set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="26"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="44"/>
        <location filename="../guipanel.ui" line="1104"/>
        <location filename="../guipanel.ui" line="1394"/>
        <location filename="../guipanel.ui" line="1633"/>
        <location filename="../guipanel.ui" line="2038"/>
        <location filename="../guipanel.ui" line="2092"/>
        <location filename="../guipanel.ui" line="2400"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="59"/>
        <source>Set material used by this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="75"/>
        <source>Click to follow material (if known in module.ini).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="78"/>
        <source>&lt;a href=&quot;link&quot;&gt;Material&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="97"/>
        <source>Number of vertices of this mesh, including seams.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="122"/>
        <location filename="../guipanel.ui" line="1138"/>
        <location filename="../guipanel.ui" line="2196"/>
        <source>000000000000; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="138"/>
        <location filename="../guipanel.ui" line="1116"/>
        <location filename="../guipanel.ui" line="1820"/>
        <location filename="../guipanel.ui" line="2174"/>
        <source>Flags:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="160"/>
        <source>Diffuse texture name (depends on material)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="179"/>
        <source>Texture:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="198"/>
        <location filename="../guipanel.ui" line="2703"/>
        <source>faces:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="217"/>
        <source>Number of triangles of this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="236"/>
        <source>vert:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="255"/>
        <source>Number of different X,Y, Z position of this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="277"/>
        <source>pos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="296"/>
        <source>Number of frames (&gt;1 for vertex animated meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="321"/>
        <source>frames:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="346"/>
        <source>Time of frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="384"/>
        <source>Time of this frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="403"/>
        <location filename="../guipanel.ui" line="1618"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="433"/>
        <source>Vertex Anim.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="452"/>
        <source>Rigged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="471"/>
        <source>Vertex Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="490"/>
        <source>Tangent Dirs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="513"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="552"/>
        <source>Skin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="568"/>
        <source>Select a reference skin to show this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="597"/>
        <source>Show no color (all white).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="600"/>
        <source>No Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="613"/>
        <source>Use vertex color as defined in the BRF file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="616"/>
        <source>Vertex Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="632"/>
        <source>Enable disable lighting,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="635"/>
        <source>Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="651"/>
        <source>Show rigging by coloring mesh according to attached bones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="654"/>
        <source>Rigging Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="667"/>
        <source>Show/hide wireframe.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="670"/>
        <source>WireFrame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="683"/>
        <source>Enable disable texture mapping.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="686"/>
        <source>Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="689"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="705"/>
        <source>BumpMap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="721"/>
        <source>SpecMap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="744"/>
        <source>Show/hide a floor at Y = 0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="747"/>
        <source>Floor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="773"/>
        <location filename="../guipanel.ui" line="792"/>
        <source>Current weapon reach.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="814"/>
        <source>Show ruler to measure weapon reach.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="817"/>
        <source>Ruler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="843"/>
        <source>Select a reference animation to view rigged meshes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="856"/>
        <source>Animation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="882"/>
        <source>Skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="898"/>
        <source>Select a reference skeleton (e.g. human or horse)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="926"/>
        <source>Pause the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="929"/>
        <source>||</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="947"/>
        <source>Play the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="950"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="968"/>
        <source>Stop the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="971"/>
        <source>[]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="989"/>
        <source>Next frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="992"/>
        <source>&gt;|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1010"/>
        <source>Prev frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1013"/>
        <source>|&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1036"/>
        <source>Show RGB channel of texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1039"/>
        <source>&amp;RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1055"/>
        <source>Show alpha transparency (alpha = 0 means transparent).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1058"/>
        <source>Alpha &amp;Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1071"/>
        <source>Show alpha channel of textures.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1074"/>
        <source>&amp;Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1135"/>
        <source>Texture flags (unknown meaning)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1157"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1173"/>
        <source>res:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1205"/>
        <source>Space taken on disk (compressed).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1240"/>
        <source>KBytes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1272"/>
        <source># mipmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1294"/>
        <source>Format of dds file on disk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1313"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1329"/>
        <source>Click to go back to the material.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1335"/>
        <location filename="../guipanel.ui" line="2008"/>
        <location filename="../guipanel.ui" line="2383"/>
        <source>(&lt;a href=&quot;link&quot;&gt;back&lt;/a&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1351"/>
        <source>location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1380"/>
        <source>open it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1406"/>
        <source>First frame of the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1425"/>
        <source>Number of bones this animation is made for.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1444"/>
        <source>Number of frames in this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1463"/>
        <source>Last frame of the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1482"/>
        <location filename="../guipanel.ui" line="2050"/>
        <source># bones:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1498"/>
        <source># frames:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1514"/>
        <source>interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1530"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1555"/>
        <source>time of frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1568"/>
        <source>Frame number (1 = first)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1599"/>
        <source>Time of this frame (must always be increasing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1645"/>
        <source>Shader used by this material.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1658"/>
        <source>Main diffuse (RGB color) texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1671"/>
        <source>Second diffuse (RGB color) texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1684"/>
        <source>Bumpmap texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1697"/>
        <source>Environment map texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1710"/>
        <source>Red component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1723"/>
        <source>Green component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1736"/>
        <source>Blue component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1749"/>
        <source>Spec RGB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1765"/>
        <source>Specular map texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1778"/>
        <source>Coeff:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1794"/>
        <source>Specular coefficient (glossiness). Higher = smaller brighter reflections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1807"/>
        <source>Flags (click on button to edit bits)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="417"/>
        <location filename="../guipanel.ui" line="1836"/>
        <location filename="../guipanel.ui" line="2024"/>
        <location filename="../guipanel.ui" line="2758"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="119"/>
        <source>Mesh flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1849"/>
        <source>Rend.Ord:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1865"/>
        <source>Rendering order (negative = soonest)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1884"/>
        <source>Click to open file containing shader.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1887"/>
        <source>&lt;a href=&quot;link&quot;&gt;Shader&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1903"/>
        <location filename="../guipanel.ui" line="1922"/>
        <source>Click to open file containing this texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1906"/>
        <source>&lt;a href=&quot;link&quot;&gt;DiffuseA&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1925"/>
        <source>&lt;a href=&quot;link&quot;&gt;DiffuseB&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1941"/>
        <source>Click to open file containing this bumpmap,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1944"/>
        <source>&lt;a href=&quot;link&quot;&gt;Bump&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1960"/>
        <source>Click to open file containing this environment map.</source>
        <oldsource>Click to open file containing this enviornment map.</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1963"/>
        <source>&lt;a href=&quot;link&quot;&gt;Enviro&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1979"/>
        <source>Click to open file containing this specular map.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1982"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;link&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;Specular&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2002"/>
        <source>Click to go back to the mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2066"/>
        <source>Number of bones composing this skeleton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2104"/>
        <source>Technique:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2120"/>
        <location filename="../guipanel.ui" line="2129"/>
        <source>Technique: name of the &quot;technique&quot; inside mb.fx file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2142"/>
        <source>Fallback:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2158"/>
        <source>Which other shader to use if requirements are not met.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2193"/>
        <source>Shader flags (no known meaning).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2215"/>
        <source>Specify if a DDX version is required here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2231"/>
        <source>Requires:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2247"/>
        <source>texture access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2259"/>
        <source>map:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2315"/>
        <source>colorOp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2331"/>
        <source>alphaOp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2347"/>
        <location filename="../guipanel.ui" line="2729"/>
        <source>flags:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2367"/>
        <source>Texture access index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2415"/>
        <source>Select a subpiece composing this collision object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2431"/>
        <source>piece</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2506"/>
        <source>axisA:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2532"/>
        <source>axisB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2606"/>
        <source>radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2661"/>
        <source>verts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2781"/>
        <source>sign:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2827"/>
        <source>piece list:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="3209"/>
        <source>Navigate: cannot find &quot;%1&quot; in current module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="19"/>
        <source>Select Module folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="24"/>
        <source>Not a recognized module folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="134"/>
        <location filename="../main_ImpExp.cpp" line="166"/>
        <location filename="../main_ImpExp.cpp" line="186"/>
        <location filename="../main_ImpExp.cpp" line="212"/>
        <location filename="../main_ImpExp.cpp" line="234"/>
        <location filename="../main_ImpExp.cpp" line="267"/>
        <location filename="../main_ImpExp.cpp" line="284"/>
        <location filename="../main_ImpExp.cpp" line="297"/>
        <location filename="../main_ImpExp.cpp" line="337"/>
        <location filename="../main_ImpExp.cpp" line="357"/>
        <location filename="../main_ImpExp.cpp" line="387"/>
        <location filename="../main_ImpExp.cpp" line="394"/>
        <location filename="../main_ImpExp.cpp" line="419"/>
        <location filename="../main_ImpExp.cpp" line="437"/>
        <location filename="../main_ImpExp.cpp" line="599"/>
        <location filename="../main_ImpExp.cpp" line="629"/>
        <location filename="../main_ImpExp.cpp" line="650"/>
        <location filename="../main_ImpExp.cpp" line="692"/>
        <location filename="../main_ImpExp.cpp" line="702"/>
        <location filename="../main_ImpExp.cpp" line="820"/>
        <location filename="../main_ImpExp.cpp" line="879"/>
        <location filename="../main_ImpExp.cpp" line="934"/>
        <location filename="../main_ImpExp.cpp" line="952"/>
        <source>Open Brf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="135"/>
        <source>Cannot open file for writing;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="156"/>
        <source>Select a folder to export all meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="167"/>
        <source>Cannot open file %1 for writing;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="187"/>
        <location filename="../main_ImpExp.cpp" line="235"/>
        <location filename="../main_ImpExp.cpp" line="285"/>
        <source>Cannot export animation without a proper skeleton!
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="213"/>
        <source>Cannot export rigged mesh:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="268"/>
        <source>Cannot export rest-pose:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="298"/>
        <source>Cannot export animation:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="338"/>
        <source>Cannot export skeleton:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="358"/>
        <source>Cannot export control mesh in file 
&quot;%1&quot;

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="370"/>
        <location filename="../main_ImpExp.cpp" line="670"/>
        <source>mesh file (*.obj *.ply *.off *.stl *.dae)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="388"/>
        <source>Cannot read mesh!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="395"/>
        <source>Modification of skeleton with mesh: fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="420"/>
        <source>Cannot write file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="433"/>
        <source>Quake 3 vertex animation (*.MD3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="438"/>
        <source>Error exporting MD3 file
: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="520"/>
        <source>Import file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="526"/>
        <location filename="../main_ImpExp.cpp" line="544"/>
        <source>Import canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="538"/>
        <source>Import files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="576"/>
        <source>Export file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="577"/>
        <source>%1\%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="581"/>
        <source>Export canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="600"/>
        <source>Cannot import file %1:
%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="622"/>
        <source>Warband or M&amp;B resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="630"/>
        <source>Cannot import file %1

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="642"/>
        <source>mesh file (*.obj)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="651"/>
        <location filename="../main_ImpExp.cpp" line="693"/>
        <source>Cannot import file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="703"/>
        <source>Cannot import file %1

(error: %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="733"/>
        <location filename="../mainwindow.cpp" line="1041"/>
        <location filename="../mainwindow.cpp" line="1042"/>
        <location filename="../mainwindow.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="734"/>
        <source>Mesh &quot;%1&quot; has multiple materials\objects.
Import a separate mesh per material\object?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="749"/>
        <source>Imported mesh &quot;%1&quot;--- normals:%2 colors:%3 texture_coord:%4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="767"/>
        <source>Import vertex animation frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="768"/>
        <source>Frist select a mesh
to add a frame to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="777"/>
        <source>Import failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="787"/>
        <location filename="../mainwindow.cpp" line="1911"/>
        <source>Vertex number mismatch... using texture-coord matching instead of vertex-ordering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="802"/>
        <location filename="../mainwindow.cpp" line="1918"/>
        <source>Added frame %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="804"/>
        <source>Added frames %1..%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="821"/>
        <source>Cannot import animation:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="839"/>
        <source>Found no time value in SMD file, so I added them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="880"/>
        <source>Cannot import skeleton:
%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="892"/>
        <source>Imported skeleton &quot;%1&quot;--- nbones:%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="935"/>
        <source>Cannot import mesh %2:
%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="953"/>
        <source>%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="960"/>
        <source>Imported %1 rigged mesh%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="9"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="22"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="38"/>
        <source>&amp;Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="57"/>
        <source>Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="72"/>
        <source>Navigate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="78"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="82"/>
        <source>&amp;Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="93"/>
        <source>On import meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="95"/>
        <source>On assemble vertex animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="133"/>
        <source>merge vertices and pos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="135"/>
        <source>recompute normals and merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="137"/>
        <source>do nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="150"/>
        <source>trust vertex order to be the same</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="151"/>
        <source>Use this option if you feel lucky and hope that vertex order was preserved between the frames.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="153"/>
        <source>trust texture coordinates to be unique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="155"/>
        <source>Use this option if you think that each vertex can be identified uniquely by its texture coords (best option)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="157"/>
        <source>quiver mode - start with max arrows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="158"/>
        <source>When you add a frame: what is not in the exact same position as the 1st frame disappears</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="176"/>
        <source>Auto zoom-and-recenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="177"/>
        <source>according to selected object(s) only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="179"/>
        <source>according to all objects in file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="211"/>
        <source>Darkest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="212"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="213"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="214"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="215"/>
        <source>Lightest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="218"/>
        <source>When computing AO, use %1 shades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="250"/>
        <source>Store in per-vertex Alpha (not RGB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="256"/>
        <source>On building LOD pyramids...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="257"/>
        <source>Set the way OpenBRF build LODs pyramids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="261"/>
        <source>Background color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="262"/>
        <source>Sets the background color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="270"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="271"/>
        <source>System default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="280"/>
        <source>Test a custom translation file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="292"/>
        <source>Learn how to femininize armours from current meshes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="307"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="309"/>
        <source>Create a new file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="312"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="314"/>
        <source>Open an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="317"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="319"/>
        <source>Save the document to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="322"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="323"/>
        <source>Cut currently selected objects.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="325"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="326"/>
        <source>Copy currently selected objects in the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="327"/>
        <source>Add to Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="328"/>
        <source>Add currently selected objects to clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="330"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="331"/>
        <source>Paste objects from the clipboard into currect BRF.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="335"/>
        <source>Cut frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="337"/>
        <source>Cut current frame of a vertex animated mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="338"/>
        <source>Copy frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="340"/>
        <source>Copy current frame of a vertex animated mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="342"/>
        <source>Copy complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="344"/>
        <source>Copy selected objects plus everything used by them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="346"/>
        <source>Cut complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="348"/>
        <source>Cut selected objects plus everything used by them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="350"/>
        <source>Paste frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="353"/>
        <source>Paste frame from clipboard as next frame in the current vertex animated mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="354"/>
        <source>Paste rigging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="355"/>
        <source>Make a rigging for current mesh(-es) similar to one of the meshes in the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="358"/>
        <source>Paste modifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="359"/>
        <source>Move vertices of current mesh according to a 2 frame mesh animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="362"/>
        <source>Paste timings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="363"/>
        <source>Paste timings of vertex or skeletal animation in clipboard into other animation(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="380"/>
        <source>Save &amp;As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="382"/>
        <source>Save the document under a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="392"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="393"/>
        <source>Alt+F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="394"/>
        <source>Exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="397"/>
        <source>Why the checkerboard pattern?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="398"/>
        <source>Diagnose why I&apos;m seeing a checkboard pattern instead of my texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="403"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="404"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="405"/>
        <source>About OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="408"/>
        <source>_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="412"/>
        <source>Sort entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="413"/>
        <source>Sort current entries alphabetically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="416"/>
        <source>Static mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="417"/>
        <source>Import a static Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="418"/>
        <source>Rigged mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="419"/>
        <source>Import rigged (skeletal animable) Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="420"/>
        <source>Frame of vertex-animated mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="421"/>
        <source>Import a static mesh and add it as a vertex-animation frame of current Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="422"/>
        <source>Vertex-animated mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="423"/>
        <source>Import a vertex animated mesh from a MD3 file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="424"/>
        <location filename="../main_info.cpp" line="14"/>
        <source>Skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="425"/>
        <source>Import a Skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="429"/>
        <source>Skeletal animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="430"/>
        <source>Import a skeletal Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="431"/>
        <source>Collision body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="432"/>
        <source>Import an (multi-object) OBJ mesh as a Collision object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="433"/>
        <source>Anything from a BRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="434"/>
        <source>Import all content form another BRF file into current one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="435"/>
        <source>New Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="436"/>
        <source>Make a new Material object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="437"/>
        <source>New Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="438"/>
        <source>Make a new Texture object from a dds texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="439"/>
        <source>New Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="440"/>
        <source>Enlist a new Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="442"/>
        <source>New Menu Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="443"/>
        <source>Add a Menu Background (Mesh, Material, and Texture)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="446"/>
        <source>follow link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="447"/>
        <source>ctrl+right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="448"/>
        <source>Go from a mesh to used material; go from a material to used textures/shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="450"/>
        <source>follow back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="451"/>
        <source>ctrl+left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="452"/>
        <source>Go back to the mesh (from a material) or material (from texture or shaders).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="453"/>
        <source>next back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="454"/>
        <source>prev back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="455"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="456"/>
        <location filename="../main_create.cpp" line="474"/>
        <source>ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="457"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="458"/>
        <source>Reload ini files, brf files inside it, and dds textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="459"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="460"/>
        <source>Scan module for usages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="461"/>
        <source>Scans module content and txt files, to compute what uses what</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="462"/>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="463"/>
        <source>Change current Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="464"/>
        <source>Choose the current module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="466"/>
        <source>Export names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="467"/>
        <source>Export al the contnt in a txt file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="469"/>
        <source>Scan module for errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="470"/>
        <source>ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="471"/>
        <source>Scan module.ini and included brf files for inconsistencies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="473"/>
        <source>Find in module...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="477"/>
        <source>Select a BRF in module...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="475"/>
        <source>Look for an object in all brf listed inside current module.ini.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="84"/>
        <source>Use OpenGL 2.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="86"/>
        <source>Allows to preview bumpmapping etc. This can create compatibility problems on some (older?) graphic card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="224"/>
        <source>Light mostly from above</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="225"/>
        <source>Light from all around</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="233"/>
        <source>Sample per vertex (quicker)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="234"/>
        <source>Sample per wedge (softer, better on some models)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="242"/>
        <source>On compute Ambient Occlusion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="478"/>
        <source>Select a BRF file of this module.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="479"/>
        <source>F7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="480"/>
        <source>Show unreferenced texture files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="481"/>
        <source>Show texture files non referenced in any brf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="484"/>
        <source>Show module stats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="485"/>
        <source>Show statistics for current Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="502"/>
        <source>&amp;Repeat last command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="507"/>
        <source>Register BRF extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="508"/>
        <source>Make so that clicking on a brf file opens OpenBRF.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="521"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="522"/>
        <source>Default mode: rotate objects with mouse, zoom in/out with wheel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="523"/>
        <source>helmet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="524"/>
        <source>Helmet mode: for objects with vertical Z axis, like M&amp;B helmets or weapons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="525"/>
        <source>scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="526"/>
        <source>Scene mode: navigate with mouse and WASD (levitate with wheel, zoom with shift)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="537"/>
        <source>combo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="538"/>
        <source>See objects combined, when selecting multiple things</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="539"/>
        <source>aside</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="540"/>
        <source>See object side-to-side, when selecting multiple things</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="542"/>
        <source>mult-view:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="560"/>
        <source>view-mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="10"/>
        <source>Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="11"/>
        <source>Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="12"/>
        <source>Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="13"/>
        <source>Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="15"/>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="16"/>
        <source>Collision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="17"/>
        <location filename="../main_info.cpp" line="30"/>
        <source>???</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="23"/>
        <source>Meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="24"/>
        <source>Textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="25"/>
        <source>Shaders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="26"/>
        <source>Materials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="27"/>
        <source>Skeletons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="28"/>
        <source>Animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="29"/>
        <source>Collisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="50"/>
        <source>&lt;p&gt;&amp;nbsp; &amp;nbsp; &lt;b&gt;OpenBrf&lt;/b&gt;&lt;br&gt;&amp;nbsp; &amp;nbsp; by &lt;b&gt;%2&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &lt;b&gt;ver %6&lt;/b&gt;&lt;br&gt;&amp;nbsp; &amp;nbsp; (%1)&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;i&gt;Testing, bug reporting, suggestions by:&lt;/i&gt; %3&lt;/p&gt;&lt;p&gt;&lt;i&gt;Additional art by:&lt;/i&gt; %4&lt;/p&gt;&lt;p&gt;&lt;i&gt;Translations by:&lt;/i&gt; %5&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="80"/>
        <source>additional code and Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="107"/>
        <source>&lt;b&gt;Activate OpenGL2.0?&lt;/b&gt;&lt;p&gt;OpenGL2.0 is needed to preview&lt;br&gt;bumpmaps, &quot;iron&quot; shader, specular maps...&lt;br&gt;but it has been reported to crash a few computers,&lt;br&gt;with (older?) ATI or Intel graphic cards.&lt;br&gt;&lt;br&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="113"/>
        <source>&lt;i&gt;(later you can set this option under [Settings])</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="159"/>
        <source>Open-Brf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="93"/>
        <source>&lt;b&gt;What is this autofix DXT texture option?&lt;/b&gt;&lt;br&gt;&lt;p&gt;Many DDS texture creation programs/plugins around will output DXT1 textures with a minor error in the header.&lt;/p&gt;&lt;p&gt;This error confuses me (OpenBRF) but not Mount and Blade (or many other programs).&lt;/p&gt;&lt;p&gt;(When I cannot read a texture for this or any other problem, I display a chekerboard pattern instead).&lt;/p&gt;&lt;p&gt;If you want, I can silently fix this error every time I encounter it (I&apos;ll shamelessly write on the texture dss files on disk).&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="124"/>
        <source>I don&apos;t know what the material &lt;i&gt;&quot;%1&quot;&lt;/i&gt; is.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="125"/>
        <source>I&apos;ve scanned in all file &quot;%1&quot; and didn&apos;t find a &lt;i&gt;load_mod_resource&lt;/i&gt; or &lt;i&gt;load_resource&lt;/i&gt; command that pointed me to a brf file that contained any such material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="128"/>
        <source>&lt;br&gt;- double check material name of the mesh&lt;br&gt;&lt;b&gt;or&lt;/b&gt;&lt;br&gt;- find the brf-file with the material, or create one&lt;br&gt;- add a line &lt;i&gt;load_&lt;b&gt;mod&lt;/b&gt;_resource&lt;/i&gt; in module.ini, with a text editor,&lt;br&gt;- (note the &lt;i&gt;mod&lt;/i&gt; part)!&lt;br&gt;- save module.ini&lt;br&gt;- come back, and refresh Module [f5]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="138"/>
        <source>I cannot find the file &quot;%1&quot; on disk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="139"/>
        <source>I&apos;ve looked in folders &lt;br&gt;%1&lt;br&gt; and &lt;br&gt;%2&lt;br&gt; and &lt;br&gt;%3&lt;br&gt; but it wasn&apos;t there...&lt;br&gt;Maybe it is was tiff texture? (I don&apos;t understand them).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="142"/>
        <source>&lt;br&gt;- double check DiffuesA texture name of the material&lt;br&gt;- (hint: remember you can navigate with ctrl-left/right)&lt;br&gt;&lt;b&gt;or&lt;/b&gt;&lt;br&gt;- make sure the missing texture file in mod texture folder!&lt;br&gt;- put it there if it is missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="151"/>
        <source>I cannot understand the texture format of  file &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="152"/>
        <source>I&apos;m supposed to understand .dds textures of formats DXT1 (maybe), DXT3, and DXT5.&lt;br&gt;But some kinds of DXT1 texture confuse me, and too big textures too.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="155"/>
        <source>Maybe just accept the fact... it should still show the texture in game.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="160"/>
        <source>&lt;i&gt;I could not display the real texture because:&lt;/i&gt;&lt;br&gt;&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;&lt;br&gt;%2&lt;br&gt;&lt;br&gt;&lt;b&gt;Cure: &lt;/b&gt;%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="76"/>
        <location filename="../mainwindow.cpp" line="641"/>
        <location filename="../mainwindow.cpp" line="1654"/>
        <location filename="../mainwindow.cpp" line="1665"/>
        <location filename="../mainwindow.cpp" line="2077"/>
        <source>OpenBrf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="77"/>
        <source>%1 been modified.
Save changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="78"/>
        <source>Internal reference objects have</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="78"/>
        <source>The dataset has</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="299"/>
        <source>Set %1 mesh materials to &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="353"/>
        <source>Set time of frame %1 to %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="367"/>
        <location filename="../mainwindow.cpp" line="405"/>
        <source>CAnnot find skel_human, skel_dwarf and skel_orc in reference data.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="441"/>
        <source>Invalid frame %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="450"/>
        <source>%1 meshes shrunk around bones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="462"/>
        <source>Cannot find skel_human, skel_dwarf and skel_orc in reference data.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="608"/>
        <source>Set flag(s) to &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="709"/>
        <source>Stop editing reference data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="710"/>
        <source>Stop editing &quot;reference&quot; skeletons, animations &amp; meshes, that OpenBrf uses to display data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="712"/>
        <source>Edit reference data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="713"/>
        <source>Edit &quot;reference&quot; skeletons, animations &amp; meshes, that OpenBrf uses to display data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="845"/>
        <source>New %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="841"/>
        <source>new_%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="925"/>
        <source>Oops... no skin is currently available...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="930"/>
        <source>Skin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="934"/>
        <source>Select a skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="935"/>
        <source>Select a skin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="978"/>
        <source>Vertex unified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="994"/>
        <source>Cannot merge these meshes
 (different number of frames,
 or rigged VS not rigged).
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1015"/>
        <source>Computed AO%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1015"/>
        <source>(in alpha channel)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1041"/>
        <source>Learnt how to femininize an armour
from %1 examples!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1042"/>
        <source>No mesh found to learn how to femininize an armour!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1060"/>
        <source>Warning: mesh %1 has already a feminine frame.

Overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1148"/>
        <source>Normals recomputed with %1% hard edges.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1264"/>
        <source>Shift animation timings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1265"/>
        <source>Current Interval: [%1 %2]
New interval: [%1+k %2+k]

Select k:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1283"/>
        <source>Extract Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1296"/>
        <source>Remove Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1317"/>
        <source>Cannot merge these animations
 (different number of bones).
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1500"/>
        <source>Transfer Rigging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1501"/>
        <source>Transfer rigging:
select a rigged mesh first,
then all target meshes.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1528"/>
        <source>Same skeleton:
reskeletonization canceled.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1535"/>
        <source>Different number of bones:
reskeletonization canceled.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1655"/>
        <source>Renaming %1...
new name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1666"/>
        <source>%3 common prefix for %1 %2...
new prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1666"/>
        <source>Changing the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1666"/>
        <source>Adding a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1877"/>
        <source>Copy Rigging into another mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1878"/>
        <source>Copy Rigging into another mesh:
- select one or more sample rigged mesh first,
- copy them (ctrl-C)
- then select one or more target meshes (rigged or otherwise),
- then paste rigging.

(works best if sample mesh is similar to target meshes)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1915"/>
        <source>Vertex number mismatch... using texture-coord matching instead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2042"/>
        <source>Cannot paste timings! Select *one* animated mesh or skel animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2055"/>
        <source>Pasted timings over %1 (animated) mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2061"/>
        <source>Pasted timings over %1 skeletal animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2064"/>
        <source>Cannot paste times over that</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2077"/>
        <source>To use paste modification mesh: firstcopy a 2 frames mesh. Then, select one or more destination meshes, and &quot;paste modification&quot;any vertex in any frame of the destination mesh that are in the same pos of frame 0,will be moved on the position of frame 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2215"/>
        <location filename="../mainwindow.cpp" line="2254"/>
        <source>Canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2237"/>
        <source>Mounted %1 mesh%2 on bone %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2271"/>
        <source>Added mesh %1 to set %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2292"/>
        <source>Animation %2 split in %1 chunks!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2294"/>
        <source>Animation could be auto-split (frames are too conescutive)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2301"/>
        <source>Select an &quot;actions.txt&quot; file (hint: it&apos;s in the module dir)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2302"/>
        <source>%1\actions.txt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2303"/>
        <source>Txt file(*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2306"/>
        <source>Split canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2313"/>
        <source>Nothing to split (or could not split).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2322"/>
        <source>Animation %2 split in %1 chunks -- new animation.txt file save in &quot;%3&quot;!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2702"/>
        <source>Cannot save reference file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2735"/>
        <source>Editing reference file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2760"/>
        <source>Cannot load %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2790"/>
        <source>You are saving a CommonRes file!
(i.e. not one specific of this module).

Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2796"/>
        <source>You are trying to save meshes with tangend directions in M&amp;B 1.011 file format.
Unfortunately, tangent directions can only be saved in Warband file format.
Tangent directions will not be saved...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2802"/>
        <source>Cannot write file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2805"/>
        <source>File saved!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2930"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2932"/>
        <source>Resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2949"/>
        <source>Reference file saved!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2959"/>
        <source>M&amp;B Resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2959"/>
        <source>WarBand Resource v.1 (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2962"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2983"/>
        <source> [not in module.ini]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2987"/>
        <source>%1%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2989"/>
        <source>%1 - %2%3%4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2991"/>
        <source>%1 - editing internal reference data%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3064"/>
        <source>%5 %1 brf files from module.ini of &quot;%3&quot;-- %2 msec total [%4 text/mat/shad]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3066"/>
        <source>scanned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3066"/>
        <source>ERRORS found while scanning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3393"/>
        <source>&amp;%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3414"/>
        <source>New Lod parameters set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3416"/>
        <source>Cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3492"/>
        <source>Collision objects flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3568"/>
        <location filename="../mainwindow.cpp" line="3651"/>
        <source>Material flags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTextBrowser</name>
    <message>
        <location filename="../iniData.cpp" line="127"/>
        <source>cannot open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="135"/>
        <source>expected &apos;%1&apos;,
got &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="139"/>
        <source>unexpected end of file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="169"/>
        <source>cannot read token n. %1 from:
 &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="176"/>
        <location filename="../iniData.cpp" line="184"/>
        <source>expected number istead of &apos;%1&apos; (token %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="177"/>
        <source>wrong number : %1 (not in [%2, %3]) (token %4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="194"/>
        <source>Error reading file &apos;%1&apos;,
at line %3:
%2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="236"/>
        <source>%1 %2 from &apos;%3&apos; &lt;font size=-1&gt;(&apos;%4&apos;, &apos;%5&apos;, &apos;%6&apos;...)&lt;/font&gt;

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="663"/>
        <source>%6 &lt;a href=&quot;#%1.%2.%3&quot;&gt;%4&lt;/a&gt; (in %5)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="678"/>
        <source>&lt;b&gt;File-not-found:&lt;/b&gt; can&apos;t find texture file for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="724"/>
        <source>&lt;b&gt;Missing:&lt;/b&gt; %1 uses unknown %2 &lt;u&gt;%3&lt;/u&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="730"/>
        <source>&lt;b&gt;Ordering problem:&lt;/b&gt; %1 uses %2, which appears later in &lt;i&gt;module.ini&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="753"/>
        <source>&lt;h1&gt;Module &lt;b&gt;%1&lt;/b&gt;&lt;/h1&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="759"/>
        <source>&lt;h2&gt;Original BRF files: %1&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="761"/>
        <source>&lt;h2&gt;CommonRes BRF files: %1&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="769"/>
        <source>&lt;i&gt;(used+unused)&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="770"/>
        <source>&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="776"/>
        <source>&lt;h2&gt;Txt data:&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1237"/>
        <source>&lt;b&gt;Missing in txt:&lt;/b&gt; cannot find %1 &lt;u&gt;%2&lt;/u&gt;, referred in &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1316"/>
        <source>&lt;b&gt;File-Not-Found:&lt;/b&gt; could not read brf file &lt;u&gt;%1&lt;/u&gt;, listed in module.ini file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1319"/>
        <source>&lt;b&gt;File-Format Error:&lt;/b&gt; could not read brf file &lt;u&gt;%1&lt;/u&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTextBrowser::QTextBrowser</name>
    <message>
        <location filename="../iniData.cpp" line="930"/>
        <source>&lt;i&gt;more errors to follow...&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="952"/>
        <source>&lt;i&gt;[0 results]&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="697"/>
        <source>&lt;b&gt;Duplicate:&lt;/b&gt; %1 was already defined in file %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Selector</name>
    <message>
        <location filename="../selector.cpp" line="10"/>
        <source>&amp;Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="11"/>
        <source>Te&amp;xture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="12"/>
        <source>&amp;Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="13"/>
        <source>Mat&amp;erial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="14"/>
        <source>S&amp;keleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="15"/>
        <source>&amp;Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="16"/>
        <source>&amp;Collision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="48"/>
        <source>Split via action.txt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="49"/>
        <source>Split sequence following the action.txt file. A new &quot;action [after split].txt&quot; file is also produced, which use the new animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="51"/>
        <source>Auto-split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="52"/>
        <source>Auto-split sequence into its separated chunks, separating it at lasge gaps in frames.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="55"/>
        <source>Extract interval...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="56"/>
        <source>Extract an animation from an interval of times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="58"/>
        <source>Remove interval...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="59"/>
        <source>Remove an interval of times from the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="61"/>
        <source>Merge animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="62"/>
        <source>Merge two animations into one -- intervals must be right!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="64"/>
        <location filename="../selector.cpp" line="478"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="68"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="72"/>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="74"/>
        <source>next tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="78"/>
        <source>left tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="82"/>
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="84"/>
        <source>Move this object upward in the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="87"/>
        <source>Move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="89"/>
        <source>Move this object one step down in the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="92"/>
        <source>Add to reference animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="93"/>
        <source>Add this animation to reference animations (to use it later to display rigged meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="95"/>
        <source>Add to reference skeletons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="96"/>
        <source>Add this animation to reference skeletons (to use it later for animations).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="99"/>
        <source>set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="100"/>
        <source>Add this mesh to reference skins (to use it later to display animations).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="125"/>
        <source>&lt;none&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="130"/>
        <source>mod file &lt;%1&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="132"/>
        <source>mod file &lt;%1&gt; (indirectly)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="136"/>
        <source>&lt;no .txt file&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="138"/>
        <source>&lt;core engine&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="140"/>
        <source>&lt;core engine&gt; (indirectly)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="143"/>
        <source>&lt;not in module.ini&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="145"/>
        <source>&lt;save file to find out&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="148"/>
        <source>(not computed: compute now)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="152"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="154"/>
        <source>Info on mesh import/export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="156"/>
        <source>Export static mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="157"/>
        <source>Export this model (or this frame) as a 3D static mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="159"/>
        <source>Export vertex ani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="160"/>
        <source>Export this model as a mesh with vertex animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="162"/>
        <source>Export combined mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="163"/>
        <source>Export this group of models in a single OBJ.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="164"/>
        <source>Export all meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="165"/>
        <source>Export each of these models as separate OBJs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="167"/>
        <source>Export rigged mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="168"/>
        <source>Export this model (or this frame) as a rigged mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="170"/>
        <source>Export (nude) skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="171"/>
        <source>Export this skeleton (as a set of nude bones).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="172"/>
        <source>Export skeleton with skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="173"/>
        <source>Export this skeleton (as a rigged skin).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="174"/>
        <source>Export a skin for this ani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="175"/>
        <source>Export a rigged skin which can be used for this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="177"/>
        <source>Export animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="178"/>
        <source>Export this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="180"/>
        <source>Reskeletonize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="181"/>
        <source>Adapt this rigged mesh to a new skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="183"/>
        <source>Transfer rigging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="184"/>
        <source>Copy rigging from one mesh to another</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="187"/>
        <source>Mirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="188"/>
        <source>Mirror this object on the X axis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="190"/>
        <source>Roto-translate-rescale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="191"/>
        <source>Apply a geometric transform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="193"/>
        <source>Rescale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="194"/>
        <source>Rescale this object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="196"/>
        <source>Shift time interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="197"/>
        <source>Shift a time interval for this animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="199"/>
        <source>Make quad-dominant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="200"/>
        <source>Try to merge most triangles into fewer quads (more efficient!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="201"/>
        <source>Combine collision objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="202"/>
        <source>Make a combined collision obj. unifying these objs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="204"/>
        <source>Recompute normals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="205"/>
        <source>Recompute normals for this model, and unify pos and vertices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="207"/>
        <source>Unify vertices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="208"/>
        <source>Unify identical vertices and pos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="210"/>
        <source>Combine meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="211"/>
        <source>Make a combined mesh unifying these meshes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="213"/>
        <source>Make a collision object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="214"/>
        <source>Turn this mesh(es) into a combined Collision object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="216"/>
        <source>Mount on one bone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="217"/>
        <source>Put this mesh on top of a single skeleton bone.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="219"/>
        <source>remove all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="220"/>
        <source>Remove all faces that are backfacing (e.g. in beard meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="221"/>
        <source>add (x2 faces)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="222"/>
        <source>Duplicate all faces: for each current face, add a backfacing face.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="224"/>
        <source>Color with Ambient Occlusion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="225"/>
        <source>Set per vertex color as ambient occlusion (globlal lighting)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="227"/>
        <source>Add femininized frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="228"/>
        <source>Build a feminine frame for this armour(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="230"/>
        <source>Compute LODs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="231"/>
        <source>Tries to compute a LOD pyramid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="233"/>
        <source>Color uniform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="234"/>
        <source>Set per vertex color as a uniform color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="236"/>
        <source>Recmopute tangent dirs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="237"/>
        <source>(Tangent dirs are needed for bump-mapping)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="239"/>
        <source>Tune colors HSB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="240"/>
        <source>Then Hue Saturation and Brightness of per-vertex colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="242"/>
        <source>per-vertex color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="243"/>
        <source>rigging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="244"/>
        <source>tangent directions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="245"/>
        <source>vertex animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="246"/>
        <source>Discard vertex animation (keeps only current frame)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="250"/>
        <source>Make a skeleton-modification mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="251"/>
        <source>Modify from a skeleton-modification mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="330"/>
        <source>[Right-Click]: tools for %1. Multiple selections with [Shift]-[Ctrl].</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="333"/>
        <source>[Right-Click]: tools for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="478"/>
        <source>Group rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="490"/>
        <source>Used by...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="583"/>
        <source>Backfacing faces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="588"/>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="630"/>
        <source>Add to reference skins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="633"/>
        <source>to Skin Set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="637"/>
        <source>to Skin Set %1 [new set]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TableModel</name>
    <message>
        <location filename="../tablemodel.cpp" line="73"/>
        <source>HEADER</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>askModErrorDialog</name>
    <message>
        <location filename="../askModErrorDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.ui" line="45"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.ui" line="81"/>
        <source>look in commonres too</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>askTexturenameDialog</name>
    <message>
        <location filename="../askTexturenameDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.ui" line="42"/>
        <source>name(s):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.ui" line="58"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
