<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AskBoneDialog</name>
    <message>
        <location filename="../askBoneDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="62"/>
        <source>Reference skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="78"/>
        <source>bone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="99"/>
        <source>This mesh is not skinned:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="117"/>
        <source>Select a skeleton and a bone to attach this mesh to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="130"/>
        <source>at origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="143"/>
        <source>in the correct final position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="156"/>
        <source>Piece currently centered:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="182"/>
        <source>(optional) carry location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.cpp" line="91"/>
        <source>&lt;none&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskCreaseDialog</name>
    <message>
        <location filename="../askCreaseDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="64"/>
        <source>Recomputing normals:
how many hard edges?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="83"/>
        <source>all edges soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="104"/>
        <source>all edges hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="120"/>
        <source>keep texture
seams hard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskFlagsDialog</name>
    <message>
        <location filename="../askFlagsDialog.cpp" line="58"/>
        <source>unused (?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.cpp" line="59"/>
        <source>This seems to be unused.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.cpp" line="69"/>
        <source>reserved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="17"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="26"/>
        <source>Flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="114"/>
        <source>Show all bits</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskIntervalDialog</name>
    <message>
        <location filename="../askIntervalDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="30"/>
        <location filename="../askIntervalDialog.ui" line="47"/>
        <source>0000009; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="37"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="54"/>
        <source>from:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="64"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askIntervalDialog.ui" line="71"/>
        <source>select time interval:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskLodOptionsDialog</name>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="20"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;When OpenBRF computes a &lt;/span&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;LOD (Level Of Detail) Pyramid&lt;/span&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt; for a mesh...&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="34"/>
        <source>which levels to build, and with how many faces (w.r.t. original mesh)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="40"/>
        <source>LOD1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="47"/>
        <source>LOD2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="54"/>
        <source>LOD3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="61"/>
        <source>LOD4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="103"/>
        <source>Build?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="113"/>
        <source>% faces:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="138"/>
        <source>Overwrite existing LOD Pyramid (if there is one?):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="144"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askLodOptionsDialog.ui" line="151"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskModErrorDialog</name>
    <message>
        <location filename="../askModErrorDialog.cpp" line="37"/>
        <source>Look for:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="44"/>
        <source>Any kind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="54"/>
        <source>Searching for errors...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="56"/>
        <source>&lt;i&gt;scanning data...&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="92"/>
        <source>Found 0 errors in module!</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../askModErrorDialog.cpp" line="94"/>
        <source>Found %n%1 error:</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="108"/>
        <source>&lt;i&gt;[ready]&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="126"/>
        <source>More errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="132"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="147"/>
        <source>OpenBrf -- Module %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskNewUiPictureDialog</name>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="42"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;This will create: a Mesh, a Material, and a Texture&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;which can be used ingame as a 2D decoration &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;in the background of menus.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="61"/>
        <source>Size and Pos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="76"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="83"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="102"/>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="112"/>
        <source>Lower-left
corner: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="330"/>
        <source>Actual pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="130"/>
        <source>in pixels, on a
1024x768 sceen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="444"/>
        <source>replace existing Mat.
Mesh, and Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="123"/>
        <source>in % of screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="318"/>
        <source>Align:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="337"/>
        <source>Set fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="356"/>
        <source>Picture name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="368"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="392"/>
        <source>Overlay mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="404"/>
        <source>Darken (multiply)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="417"/>
        <source>Normal (alpha blend)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="430"/>
        <source>Substitute (no alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.cpp" line="161"/>
        <source>Select a texture for a menu background file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskSelectBRFDialog</name>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="31"/>
        <source>In
Module
folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="64"/>
        <source>Files not
included in
module.ini:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="81"/>
        <source>In
Comm Res
folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="98"/>
        <source>&lt;line_num&gt;.&lt;filename&gt; (&lt;#used&gt; + &lt;#unused&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="127"/>
        <source>Open module.ini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="134"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="141"/>
        <source>Count used</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskSkelDialog</name>
    <message>
        <location filename="../askSkelDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="42"/>
        <source>cbSkelTo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="65"/>
        <source>From (current skeleton):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="81"/>
        <source>To (destination skeleton):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="102"/>
        <source>Change geometry of meshes currently skinned for a skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="120"/>
        <source>to make it follow a new skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="133"/>
        <source>Put result in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="145"/>
        <source>same mesh (overwrite)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="158"/>
        <source>new mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="171"/>
        <source>new vertex-ani frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="185"/>
        <source>Method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="197"/>
        <source>generic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="210"/>
        <source>humanoids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.cpp" line="19"/>
        <source>any other skeleton</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskTexturenameDialog</name>
    <message>
        <location filename="../askTexturenameDialog.cpp" line="19"/>
        <source>also add new %1(s) 
with the same name(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.cpp" line="73"/>
        <source>Select a texture file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskTransformDialog</name>
    <message>
        <location filename="../askTransformDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="42"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="120"/>
        <location filename="../askTransformDialog.ui" line="256"/>
        <location filename="../askTransformDialog.ui" line="680"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="136"/>
        <location filename="../askTransformDialog.ui" line="272"/>
        <location filename="../askTransformDialog.ui" line="696"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="152"/>
        <location filename="../askTransformDialog.ui" line="288"/>
        <location filename="../askTransformDialog.ui" line="712"/>
        <source>Z:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="169"/>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="596"/>
        <source>Scale %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="728"/>
        <source>Uniform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="745"/>
        <source>Apply to last selected
object only</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskUnrefTextureDialog</name>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="14"/>
        <location filename="../askUnrefTextureDialog.cpp" line="45"/>
        <location filename="../askUnrefTextureDialog.cpp" line="65"/>
        <location filename="../askUnrefTextureDialog.cpp" line="75"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="25"/>
        <source>Unused DDS files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="40"/>
        <source>Note: these are the files which are not included
 in any BRF file as textures.
They will not be even loaded by the game.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="77"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="94"/>
        <source>Move all to subfolder &quot;_unused&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.cpp" line="46"/>
        <source>Move %1 textures to folder
%2 ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.cpp" line="65"/>
        <source>Moved %1 textures in new folder
%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.cpp" line="66"/>
        <source>open folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.cpp" line="66"/>
        <source>ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.cpp" line="75"/>
        <source>Error creating folder %1 in
%2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskUvTransformDialog</name>
    <message>
        <location filename="../askUvTransformDialog.ui" line="14"/>
        <source>UV transform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUvTransformDialog.ui" line="42"/>
        <source>Scale %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUvTransformDialog.ui" line="76"/>
        <location filename="../askUvTransformDialog.ui" line="187"/>
        <source>U:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUvTransformDialog.ui" line="92"/>
        <location filename="../askUvTransformDialog.ui" line="203"/>
        <source>V:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUvTransformDialog.ui" line="131"/>
        <source>Translate (in 0..1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUvTransformDialog.ui" line="220"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUvTransformDialog.ui" line="233"/>
        <source>Flip U</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="14"/>
        <source>Tune Per-Vertex Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="42"/>
        <source>Hue:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="58"/>
        <source>Saturation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="74"/>
        <source>Brightness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askHueSatBriDialog.ui" line="190"/>
        <source>Contrast:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GLWidget</name>
    <message>
        <location filename="../glwidgets.cpp" line="589"/>
        <source>&lt;br /&gt;Vertex compilation: &lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="597"/>
        <source>&lt;br /&gt;Fragment compilation: &lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="602"/>
        <source>&lt;br /&gt;Linking: &lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="608"/>
        <source>&lt;br /&gt;Binding: &lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1268"/>
        <source>&quot;green&quot; NM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1268"/>
        <source>&quot;blue&quot; NM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1271"/>
        <source>Custom User Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1274"/>
        <source>Deafult (fixed functionality)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1275"/>
        <source>Alpha to Shininess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1276"/>
        <source>Plain NormalMap (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1277"/>
        <source>NormalMap + Alpha to Transparency (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1278"/>
        <source>NormalMap + Alpha to Shininiess (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1279"/>
        <source>NormalMap + ShininessMap (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1320"/>
        <source>Scene mode: navigate with mouse and WASD (levitate with wheel, zoom in with shift)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1325"/>
        <source>Helmet mode: for objects with vertical Z axis, like M&amp;B helmets or weapons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1327"/>
        <source>Default mode: rotate objects with mouse, zoom in/out with wheel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="1438"/>
        <source>Error parsing %1:

maybe the problem is that a shader uses the sign (&lt;) or (&gt;) or (&amp;)?

(it&apos;s xml: must use &amp;lt; or &amp;gt; or &amp;amp; instead!)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GuiPanel</name>
    <message>
        <location filename="../guipanel.cpp" line="165"/>
        <location filename="../guipanel.cpp" line="176"/>
        <source>unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="166"/>
        <source>not-found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="167"/>
        <source>common</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="168"/>
        <source>module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="169"/>
        <source>local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="173"/>
        <source>DXT 1 (1bit alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="174"/>
        <source>DXT 3 (sharp alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="175"/>
        <source>DXT 5 (smooth alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="364"/>
        <source> (keep [shift] pressed to nudge)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.cpp" line="479"/>
        <source>Mesh-set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="26"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="44"/>
        <location filename="../guipanel.ui" line="1271"/>
        <location filename="../guipanel.ui" line="1584"/>
        <location filename="../guipanel.ui" line="1823"/>
        <location filename="../guipanel.ui" line="2176"/>
        <location filename="../guipanel.ui" line="2275"/>
        <location filename="../guipanel.ui" line="2609"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="59"/>
        <source>Set material used by this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="75"/>
        <source>Click to follow material (if known in module.ini).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="78"/>
        <source>&lt;a href=&quot;link&quot;&gt;Material&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="97"/>
        <source>Number of vertices of this mesh, including seams.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="122"/>
        <location filename="../guipanel.ui" line="1305"/>
        <location filename="../guipanel.ui" line="2379"/>
        <source>000000000000; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="138"/>
        <location filename="../guipanel.ui" line="1283"/>
        <location filename="../guipanel.ui" line="2010"/>
        <location filename="../guipanel.ui" line="2357"/>
        <source>Flags:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="160"/>
        <source>Diffuse texture name (depends on material)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="179"/>
        <source>Texture:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="198"/>
        <location filename="../guipanel.ui" line="2925"/>
        <source>faces:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="217"/>
        <source>Number of triangles of this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="236"/>
        <source>vert:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="255"/>
        <source>Number of different X,Y, Z position of this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="277"/>
        <source>pos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="296"/>
        <source>Number of frames (&gt;1 for vertex animated meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="318"/>
        <source>frames:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="343"/>
        <source>Time of frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="381"/>
        <source>Time of this frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="400"/>
        <location filename="../guipanel.ui" line="1808"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="430"/>
        <source>Vertex Anim.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="449"/>
        <source>Skinned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="468"/>
        <source>Vertex Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="487"/>
        <source>Tangent Dirs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="510"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="572"/>
        <source>Skin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="617"/>
        <source>Show no color (all white).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="620"/>
        <source>No Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="633"/>
        <source>Use vertex color as defined in the BRF file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="636"/>
        <source>Vertex Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="652"/>
        <source>Enable disable lighting,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="655"/>
        <source>Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="671"/>
        <source>Show skinning by coloring mesh according to attached bones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="674"/>
        <source>Skinning Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="687"/>
        <source>Show/hide wireframe.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="690"/>
        <source>WireFrame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="703"/>
        <source>Enable disable texture mapping.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="706"/>
        <source>Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="709"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="725"/>
        <source>BumpMap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="741"/>
        <source>SpecMap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="764"/>
        <source>Show/hide a floor at Y = 0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="767"/>
        <source>Floor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="793"/>
        <location filename="../guipanel.ui" line="812"/>
        <source>Current weapon reach.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="834"/>
        <source>Show ruler to measure weapon reach.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="961"/>
        <source>Select a reference animation to view skinned meshes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="974"/>
        <source>Animation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1000"/>
        <source>Skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1016"/>
        <source>Select a reference skeleton (e.g. human or horse)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1093"/>
        <source>Pause the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1096"/>
        <source>||</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1114"/>
        <source>Play the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1117"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1135"/>
        <source>Stop the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1138"/>
        <source>[]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1156"/>
        <source>Next frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1159"/>
        <source>&gt;|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1177"/>
        <source>Prev frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1180"/>
        <source>|&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1203"/>
        <source>Show RGB channel of texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1206"/>
        <source>&amp;RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1222"/>
        <source>Show alpha transparency (alpha = 0 means transparent).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1225"/>
        <source>Alpha &amp;Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1238"/>
        <source>Show alpha channel of textures.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1241"/>
        <source>&amp;Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1302"/>
        <source>Texture flags (unknown meaning)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1324"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1340"/>
        <source>res:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1372"/>
        <source>Space taken on disk (compressed).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1407"/>
        <source>KBytes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1439"/>
        <source># mipmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1461"/>
        <source>Format of dds file on disk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1480"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1496"/>
        <source>Click to go back to the material.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1502"/>
        <location filename="../guipanel.ui" line="2159"/>
        <location filename="../guipanel.ui" line="2566"/>
        <source>(&lt;a href=&quot;link&quot;&gt;back&lt;/a&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1518"/>
        <source>location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1547"/>
        <source>open it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1596"/>
        <source>First frame of the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1615"/>
        <source>Number of bones this animation is made for.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1634"/>
        <source>Number of frames in this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1653"/>
        <source>Last frame of the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1672"/>
        <location filename="../guipanel.ui" line="2188"/>
        <source># bones:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1688"/>
        <source># frames:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1704"/>
        <source>interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1720"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1745"/>
        <source>time of frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1758"/>
        <source>Frame number (1 = first)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1789"/>
        <source>Time of this frame (must always be increasing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1835"/>
        <source>Shader used by this material.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1848"/>
        <source>Main diffuse (RGB color) texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1861"/>
        <source>Second diffuse (RGB color) texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1874"/>
        <source>Bumpmap texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1887"/>
        <source>Environment map texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1900"/>
        <source>Red component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1913"/>
        <source>Green component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1926"/>
        <source>Blue component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1939"/>
        <source>Spec RGB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1955"/>
        <source>Specular map texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1968"/>
        <source>Coeff:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1984"/>
        <source>Specular coefficient (glossiness). Higher = smaller brighter reflections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1997"/>
        <source>Flags (click on button to edit bits)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2137"/>
        <source>&lt;a href=&quot;link&quot;&gt;Specular&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3066"/>
        <source>Edit Bone Hitbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3078"/>
        <source>Thinkness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3094"/>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3110"/>
        <source>Elnongate from top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3126"/>
        <source>Elongate from bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3142"/>
        <source>Move front/back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3158"/>
        <source>Move left/right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3174"/>
        <source>Move near/far</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3190"/>
        <source>Pitch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3206"/>
        <source>Yaw</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3222"/>
        <source>Pos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3238"/>
        <source>Rotat:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3254"/>
        <source>Does current bone use a Hit-box?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3257"/>
        <source>Exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3270"/>
        <source>Reset hitbox near to bone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3273"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3286"/>
        <source>Enforce symmetry for this hitbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3289"/>
        <source>Apply
Symmetry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3303"/>
        <source>Capsule used only for ragdoll, or also as a hitobx? (warband only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3306"/>
        <source>Ragdoll only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3320"/>
        <source>Vertex Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3350"/>
        <source>xyz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3362"/>
        <source>CheckBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3368"/>
        <source>rgb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3396"/>
        <source>rrggbbaa:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3464"/>
        <source>Hue:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3480"/>
        <source>Saturation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3496"/>
        <source>Brighness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3505"/>
        <source>uv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3510"/>
        <source>skn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3626"/>
        <source>nor-
ma-
li-
ze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3635"/>
        <source>n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3640"/>
        <source>t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="414"/>
        <location filename="../guipanel.ui" line="1560"/>
        <location filename="../guipanel.ui" line="2026"/>
        <location filename="../guipanel.ui" line="2582"/>
        <location filename="../guipanel.ui" line="2595"/>
        <location filename="../guipanel.ui" line="2980"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="119"/>
        <source>Mesh flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="540"/>
        <source>Compare with mesh (M)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="543"/>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="588"/>
        <source>Select a reference skin to show (toggle with [space] ).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="837"/>
        <source>Ruler:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="863"/>
        <source>Floating Probe XYZ:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="876"/>
        <source>Probe Position X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="901"/>
        <source>Probe Position Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="926"/>
        <source>Probe Position Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1039"/>
        <source>Hit-Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1062"/>
        <source>Floor &amp;&amp; Shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2039"/>
        <source>Click to open file containing shader.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2042"/>
        <source>&lt;a href=&quot;link&quot;&gt;Shader&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2058"/>
        <location filename="../guipanel.ui" line="2077"/>
        <source>Click to open file containing this texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2061"/>
        <source>&lt;a href=&quot;link&quot;&gt;DiffuseA&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2080"/>
        <source>&lt;a href=&quot;link&quot;&gt;DiffuseB&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2096"/>
        <source>Click to open file containing this bumpmap,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2099"/>
        <source>&lt;a href=&quot;link&quot;&gt;Bump&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2115"/>
        <source>Click to open file containing this environment map.</source>
        <oldsource>Click to open file containing this enviornment map.</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2118"/>
        <source>&lt;a href=&quot;link&quot;&gt;Enviro&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2134"/>
        <source>Click to open file containing this specular map.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2153"/>
        <source>Click to go back to the mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2204"/>
        <source>Number of bones composing this skeleton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2223"/>
        <source>bones:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2252"/>
        <source>Has HitBoxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2287"/>
        <source>Technique:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2303"/>
        <location filename="../guipanel.ui" line="2312"/>
        <source>Technique: name of the &quot;technique&quot; inside mb.fx file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2325"/>
        <source>&lt;a href=&quot;link&quot;&gt;Fallback&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2341"/>
        <source>Which other shader to use if requirements are not met.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2376"/>
        <source>Shader flags (no known meaning).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2398"/>
        <source>Specify if a DDX version is required here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2414"/>
        <source>Requires:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2430"/>
        <source>texture access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2442"/>
        <source>map:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2498"/>
        <source>colorOp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2514"/>
        <source>alphaOp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2530"/>
        <location filename="../guipanel.ui" line="2951"/>
        <source>flags:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2550"/>
        <source>Texture access index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2624"/>
        <source>Select a subpiece composing this collision object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2640"/>
        <source>piece</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2667"/>
        <source>radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2745"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2825"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2841"/>
        <source>Z:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2883"/>
        <source>verts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3003"/>
        <source>sign:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="3049"/>
        <source>piece list:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="5021"/>
        <source>Navigate: cannot find &quot;%1&quot; in current module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="21"/>
        <source>Select Module folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="26"/>
        <source>Not a recognized module folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="138"/>
        <location filename="../main_ImpExp.cpp" line="170"/>
        <location filename="../main_ImpExp.cpp" line="190"/>
        <location filename="../main_ImpExp.cpp" line="215"/>
        <location filename="../main_ImpExp.cpp" line="237"/>
        <location filename="../main_ImpExp.cpp" line="268"/>
        <location filename="../main_ImpExp.cpp" line="285"/>
        <location filename="../main_ImpExp.cpp" line="297"/>
        <location filename="../main_ImpExp.cpp" line="337"/>
        <location filename="../main_ImpExp.cpp" line="357"/>
        <location filename="../main_ImpExp.cpp" line="387"/>
        <location filename="../main_ImpExp.cpp" line="394"/>
        <location filename="../main_ImpExp.cpp" line="427"/>
        <location filename="../main_ImpExp.cpp" line="448"/>
        <location filename="../main_ImpExp.cpp" line="470"/>
        <location filename="../main_ImpExp.cpp" line="649"/>
        <location filename="../main_ImpExp.cpp" line="673"/>
        <location filename="../main_ImpExp.cpp" line="736"/>
        <location filename="../main_ImpExp.cpp" line="744"/>
        <location filename="../main_ImpExp.cpp" line="754"/>
        <location filename="../main_ImpExp.cpp" line="796"/>
        <location filename="../main_ImpExp.cpp" line="889"/>
        <location filename="../main_ImpExp.cpp" line="906"/>
        <location filename="../main_ImpExp.cpp" line="925"/>
        <location filename="../main_ImpExp.cpp" line="1009"/>
        <location filename="../main_ImpExp.cpp" line="1069"/>
        <source>Open Brf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="139"/>
        <source>Cannot open file for writing;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="160"/>
        <source>Select a folder to export all meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="171"/>
        <location filename="../main_ImpExp.cpp" line="428"/>
        <source>Cannot open file %1 for writing;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="191"/>
        <location filename="../main_ImpExp.cpp" line="238"/>
        <location filename="../main_ImpExp.cpp" line="286"/>
        <source>Cannot export animation without a proper skeleton!
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="216"/>
        <source>Cannot export skinned mesh:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="269"/>
        <source>Cannot export rest-pose:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="298"/>
        <source>Cannot export animation:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="338"/>
        <source>Cannot export skeleton:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="358"/>
        <source>Cannot export control mesh in file 
&quot;%1&quot;

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="370"/>
        <source>mesh file (*.obj *.ply *.off *.stl *.dae)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="388"/>
        <source>Cannot read mesh!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="395"/>
        <source>Modification of skeleton with mesh: fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="416"/>
        <source>Select a folder to export all coll meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="449"/>
        <source>Cannot write file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="471"/>
        <source>Error exporting MD3 file
: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="554"/>
        <location filename="../main_ImpExp.cpp" line="576"/>
        <source>Import file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="560"/>
        <location filename="../main_ImpExp.cpp" line="592"/>
        <source>Import canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="585"/>
        <source>Import files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="624"/>
        <source>Export file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="625"/>
        <source>%1\%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="629"/>
        <source>Export canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="712"/>
        <source>mesh file (*.obj *.ply *.off *.stl %1*.dae)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="737"/>
        <source>Cannot import file %1:
%2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="797"/>
        <source>Cannot import file %1:
%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="642"/>
        <source>Warband or M&amp;B resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="650"/>
        <source>Cannot import file %1

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="663"/>
        <source>mesh file (*.obj)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="674"/>
        <location filename="../main_ImpExp.cpp" line="745"/>
        <source>Cannot import file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="755"/>
        <source>Cannot import file %1

(error: %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <location filename="../main_ImpExp.cpp" line="820"/>
        <location filename="../mainwindow.cpp" line="1668"/>
        <location filename="../mainwindow.cpp" line="1691"/>
        <location filename="../mainwindow.cpp" line="1694"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="821"/>
        <source>Mesh &quot;%1&quot; has multiple materials\objects.
Import a separate mesh per material\object?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="765"/>
        <source>Imported mesh &quot;%1&quot;--- normals:%2 colors:%3 texture_coord:%4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="462"/>
        <source>Quake 3 vertex animation (*.MD3);;Sequence of Obj (*.000.obj)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="890"/>
        <source>No mesh found in %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="950"/>
        <source>Import vertex animation frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="951"/>
        <source>Frist select a mesh
to add a frame to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="960"/>
        <source>Import failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="970"/>
        <location filename="../mainwindow.cpp" line="3201"/>
        <source>Vertex number mismatch... using texture-coord matching instead of vertex-ordering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="985"/>
        <location filename="../mainwindow.cpp" line="3208"/>
        <source>Added frame %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="987"/>
        <source>Added frames %1..%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="1010"/>
        <source>Cannot import animation:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="1027"/>
        <source>Found no time value in SMD file, so I added them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="1070"/>
        <source>Cannot import skeleton:
%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="1082"/>
        <source>Imported skeleton &quot;%1&quot;--- nbones:%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="907"/>
        <source>Cannot import mesh %2:
%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="926"/>
        <source>%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="933"/>
        <source>Imported %1 skinned mesh%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="11"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="12"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="13"/>
        <source>&amp;Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="107"/>
        <source>Navigate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="15"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="165"/>
        <source>On import meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="238"/>
        <source>On assemble vertex animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="210"/>
        <source>merge vertices and pos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="212"/>
        <source>recompute normals and merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="214"/>
        <source>do nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="227"/>
        <source>trust vertex order to be the same</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="228"/>
        <source>Use this option if you feel lucky and hope that vertex order was preserved between the frames.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="230"/>
        <source>trust texture coordinates to be unique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="232"/>
        <source>Use this option if you think that each vertex can be identified uniquely by its texture coords (best option)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="234"/>
        <source>quiver mode - start with max arrows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="235"/>
        <source>When you add a frame: what is not in the exact same position as the 1st frame disappears</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="151"/>
        <source>Auto zoom-and-recenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="152"/>
        <source>according to selected object(s) only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="154"/>
        <source>according to all objects in file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="281"/>
        <source>Darkest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="282"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="283"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="284"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="285"/>
        <source>Lightest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="288"/>
        <source>When computing AO, use %1 shades</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="321"/>
        <source>Store in per-vertex Alpha (not RGB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="351"/>
        <source>On building LOD pyramids...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="352"/>
        <source>Set the way OpenBRF build LODs pyramids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="143"/>
        <source>Background color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="134"/>
        <source>Use preview Shaders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="144"/>
        <source>Sets the background color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="360"/>
        <source>use Mod-specific ones if possible (&quot;&lt;module-folder&gt;/Resources/reference.brf&quot;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="382"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="383"/>
        <source>System default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="392"/>
        <source>Test a custom translation file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="421"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="423"/>
        <source>Create a new file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="426"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="428"/>
        <source>Open an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="431"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="433"/>
        <source>Save the document to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="444"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="445"/>
        <source>Cut currently selected objects.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="447"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="448"/>
        <source>Copy currently selected objects in the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="449"/>
        <source>Add to Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="450"/>
        <source>Add currently selected objects to clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="452"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="453"/>
        <source>Paste objects from the clipboard into currect BRF.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="457"/>
        <source>Cut frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="459"/>
        <source>Cut current frame of a vertex animated mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="460"/>
        <source>Copy frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="462"/>
        <source>Copy current frame of a vertex animated mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="464"/>
        <source>Copy complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="466"/>
        <source>Copy selected objects plus everything used by them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="468"/>
        <source>Copy hit-boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="469"/>
        <source>Copy hitboxes of current skeleton, as defined in XML file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="471"/>
        <source>Cut complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="473"/>
        <source>Cut selected objects plus everything used by them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="475"/>
        <source>Paste frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="478"/>
        <source>Paste frame from clipboard as next frame in the current vertex animated mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="480"/>
        <source>Paste skinning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="481"/>
        <source>Make a skinning for current mesh(-es) similar to one of the meshes in the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="493"/>
        <source>Transfer vert colors from the mesh in the clipboard %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="497"/>
        <source>Try to trasnfer vert animations (good for face morph, can work only for very similar meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="501"/>
        <source>Transfer lower parts of this ani from the animation in the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="509"/>
        <source>Transfer timings of vertex or skeletal animation in clipboard into other animation(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="500"/>
        <source>Paste lower parts of animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="504"/>
        <source>Paste modifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="505"/>
        <source>Move vertices of current mesh according to a 2 frame mesh animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="508"/>
        <source>Paste timings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="512"/>
        <source>Paste hit-boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="513"/>
        <source>Paste hit-boxes into current skeleton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="540"/>
        <source>Save &amp;As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="542"/>
        <source>Save the document under a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="545"/>
        <source>Save module hitbox-sets for all skeletons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="548"/>
        <source>Create scene prop code for module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="549"/>
        <source>Create scene prop text for current meshes and collision bodies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="562"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="563"/>
        <source>Alt+F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="564"/>
        <source>Exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="569"/>
        <source>Why the checkerboard pattern?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="570"/>
        <source>Diagnose why I&apos;m seeing a checkboard pattern instead of my texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="576"/>
        <source>On mesh recoloring (info)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="580"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="581"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="582"/>
        <source>About OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="585"/>
        <source>_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="587"/>
        <source>Enter vertex-data editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="588"/>
        <source>Exit vertex-data editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="594"/>
        <source>Sort entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="595"/>
        <source>Sort current entries alphabetically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="598"/>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="599"/>
        <source>Invert current selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="603"/>
        <source>Select all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="604"/>
        <source>Select all items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="608"/>
        <source>Measure with ruler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="609"/>
        <source>Use a ruler to measure object lenghts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="613"/>
        <source>Measure with Floating Probe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="614"/>
        <source>Use the Floating Probe -- click on the 3D object rendering to position it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="619"/>
        <source>Import a static Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="621"/>
        <source>Import skinned (skeletal animable) Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="623"/>
        <source>Import a static mesh and add it as a vertex-animation frame of current Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="625"/>
        <source>Import a vertex animated mesh from a MD3 file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="16"/>
        <source>Skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="627"/>
        <source>Import a Skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="631"/>
        <source>Import a skeletal Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="633"/>
        <source>Import an (multi-object) OBJ mesh as a Collision object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="635"/>
        <source>Import all content form another BRF file into current one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="637"/>
        <source>Make a new Material object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="639"/>
        <source>Make a new Texture object from a dds texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="641"/>
        <source>Enlist a new Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="644"/>
        <source>Add a Menu Background (Mesh, Material, and Texture)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="646"/>
        <source>follow link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="648"/>
        <source>Go from a mesh to used material; go from a material to used textures/shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="650"/>
        <source>follow back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="652"/>
        <source>Go back to the mesh (from a material) or material (from texture or shaders).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="653"/>
        <source>next back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="654"/>
        <source>prev back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="656"/>
        <location filename="../main_create.cpp" line="686"/>
        <source>ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="658"/>
        <source>Reload ini files, brf files inside it, and dds textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="659"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="660"/>
        <source>Scan module for usages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="661"/>
        <source>Scans module content and txt files, to compute what uses what</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="662"/>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="664"/>
        <source>Choose the current module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="666"/>
        <source>Open Module folder in explorer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="679"/>
        <source>Export al the contnt in a txt file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="681"/>
        <source>Scan module for errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="682"/>
        <source>ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="683"/>
        <source>Scan module.ini and included brf files for inconsistencies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="685"/>
        <source>Find in module...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="689"/>
        <source>Select a BRF in module...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="687"/>
        <source>Look for an object in all brf listed inside current module.ini.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="14"/>
        <source>&amp;Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="16"/>
        <source>&amp;Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="17"/>
        <source>Setti&amp;ngs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="136"/>
        <source>Allows to preview bumpmapping etc. This can create compatibility problems on some (older?) graphic card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="294"/>
        <source>Light mostly from above</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="295"/>
        <source>Light from all around</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="303"/>
        <source>Sample per vertex (quicker)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="304"/>
        <source>Sample per wedge (softer, better on some models)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="313"/>
        <source>On compute Ambient Occlusion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="327"/>
        <source>On armour auto-feminization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="329"/>
        <source>use default settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="332"/>
        <source>use custom settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="341"/>
        <source>Learn custom setting from selected meshes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="342"/>
        <source>Use currently selected armours as examples to learn how to auto-feminize armours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="361"/>
        <source>always use shared reference files (&quot;&lt;OpenBRF-folder&gt;/reference.brf&quot;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="371"/>
        <source>Reference items mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="416"/>
        <source>manual edits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="417"/>
        <source>edit flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="419"/>
        <source>(keep shift pressed to multiply)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="484"/>
        <source>Paste into mesh (matches LODs)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="485"/>
        <source>Merge mesh in clipboard with selected mesh(es). Matches LOD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="488"/>
        <source>Paste texture coords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="489"/>
        <source>Transfer texture coordiante from the mesh in the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="492"/>
        <source>Paste vert colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="496"/>
        <source>Paste vert animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="567"/>
        <source>Preview-shaders diagnostics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="568"/>
        <source>Tell me about the preview hader that is being used now.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="618"/>
        <source>Static mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="620"/>
        <source>Skinned mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="622"/>
        <source>Frame of vertex-animated mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="624"/>
        <source>Vertex-animated mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="626"/>
        <source>Skeleton...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="630"/>
        <source>Skeletal animation...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="632"/>
        <source>Collision body...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="634"/>
        <source>Anything from a BRF...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="636"/>
        <source>New Material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="638"/>
        <source>New Texture...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="640"/>
        <source>New Shader...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="643"/>
        <source>New Menu Background...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="647"/>
        <source>shift+right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="655"/>
        <source>Find...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="657"/>
        <source>Refresh all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="663"/>
        <source>Change current Module...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="667"/>
        <source>Open Module folder in file explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="669"/>
        <source>Next BRF in module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="670"/>
        <source>Open next BRF file as defined in module.ini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="672"/>
        <source>Prev BRF in module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="673"/>
        <source>Open previous BRF file as defined in module.ini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="678"/>
        <source>Export names...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="690"/>
        <source>Select a BRF file of this module.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="691"/>
        <source>F7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="692"/>
        <source>Show unreferenced texture files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="693"/>
        <source>Show texture files non referenced in any brf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="695"/>
        <source>Show module stats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="696"/>
        <source>Show statistics for current Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="714"/>
        <source>&amp;Repeat last command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="725"/>
        <source>Register BRF extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="726"/>
        <source>Make so that clicking on a brf file opens OpenBRF.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="741"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="742"/>
        <source>Default mode: rotate objects with mouse, zoom in/out with wheel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="743"/>
        <source>helmet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="744"/>
        <source>Helmet mode: for objects with vertical Z axis, like M&amp;B helmets or weapons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="745"/>
        <source>scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="746"/>
        <source>Scene mode: navigate with mouse and WASD (levitate with wheel, zoom with shift)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="757"/>
        <source>combo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="758"/>
        <source>See objects combined (when multiple things are selected)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="760"/>
        <source>See object side-to-side (when multiple things are selected)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="761"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="762"/>
        <source>See sub-parts combined (when multiple things are selected)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="759"/>
        <source>aside</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="764"/>
        <source>mult-view:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="782"/>
        <source>view-mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="12"/>
        <source>Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="13"/>
        <source>Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="14"/>
        <source>Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="15"/>
        <source>Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="17"/>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="18"/>
        <source>Collision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="19"/>
        <location filename="../main_info.cpp" line="32"/>
        <source>???</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="25"/>
        <source>Meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="26"/>
        <source>Textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="27"/>
        <source>Shaders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="28"/>
        <source>Materials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="29"/>
        <source>Skeletons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="30"/>
        <source>Animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="31"/>
        <source>Collisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="52"/>
        <source>&lt;p&gt;&amp;nbsp; &amp;nbsp; &lt;b&gt;OpenBrf&lt;/b&gt;&lt;br&gt;&amp;nbsp; &amp;nbsp; by &lt;b&gt;%2&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &lt;b&gt;ver %6&lt;/b&gt;&lt;br&gt;&amp;nbsp; &amp;nbsp; (%1)&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;i&gt;Testing, bug reporting, suggestions by:&lt;/i&gt; %3&lt;/p&gt;&lt;p&gt;&lt;i&gt;Additional art by:&lt;/i&gt; %4&lt;/p&gt;&lt;p&gt;&lt;i&gt;Translations by:&lt;/i&gt; %5&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="83"/>
        <source>additional code and Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="123"/>
        <source>&lt;p&gt;&lt;b&gt;Info on mesh recoloring:&lt;/b&gt;&lt;br/&gt;when activating any tool which assigns&lt;br/&gt;new vertex-colors to an entire mesh: &lt;ul&gt;&lt;li&gt; keep &lt;b&gt;Shift&lt;/b&gt; pressed:&lt;br/&gt;new colors will &lt;i&gt;multiply&lt;/i&gt; existing ones&lt;/li&gt;&lt;/ul&gt;(by &lt;b&gt;default&lt;/b&gt;, new colors &lt;i&gt;replace&lt;/i&gt; existing ones).&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="144"/>
        <source>&lt;br&gt;&lt;p&gt;&lt;i&gt;This info has been copyed to clipboard&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="147"/>
        <source>ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="151"/>
        <source>&lt;p&gt;&lt;i&gt;Currently used preview Shader:&lt;/i&gt;&lt;br /&gt;%1&lt;/p&gt;&lt;p&gt;&lt;br /&gt;&lt;i&gt;Shader status:&lt;/i&gt;&lt;br /&gt;%2&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="156"/>
        <source>OpenBrf - Preview Shader info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="164"/>
        <source>&lt;i&gt;&lt;br/&gt;&lt;br/&gt;(info: skeleton metadata, including hitboxes, are kept in the separate file &quot;data/skeleton_bodies.xml&quot;)&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="197"/>
        <source>&lt;br&gt;- double check DiffuesA texture name of the material&lt;br&gt;- (hint: remember you can navigate with ctrl-left/right)&lt;br&gt;&lt;b&gt;or&lt;/b&gt;&lt;br&gt;&lt;br&gt;- make sure the missing texture file in mod texture folder!&lt;br&gt;- put it there if it is missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="207"/>
        <source>I&apos;m supposed to understand .dds textures of formats DXT1 (maybe), DXT3, and DXT5.&lt;br&gt;But some kinds of DXT1 texture confuse me, and too big textures too.&lt;br&gt;Also, if graphic drivers are not up to date, I might ignore how to intepret DXT formats.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="210"/>
        <source>Try updating the drivers. Else, maybe just accept the fact... it should still show the texture in game.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="96"/>
        <source>&lt;b&gt;What is this autofix DXT texture option?&lt;/b&gt;&lt;br&gt;&lt;p&gt;Many DDS texture creation programs/plugins around will output DXT1 textures with a minor error in the header.&lt;/p&gt;&lt;p&gt;This error confuses me (OpenBRF) but not Mount and Blade (or many other programs).&lt;/p&gt;&lt;p&gt;(When I cannot read a texture for this or any other problem, I display a chekerboard pattern instead).&lt;/p&gt;&lt;p&gt;If you want, I can silently fix this error every time I encounter it (I&apos;ll shamelessly write on the texture dss files on disk).&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="109"/>
        <source>Activating preview Shaders
(can be disabled under Settings)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="176"/>
        <source>I don&apos;t know what the material &lt;i&gt;&quot;%1&quot;&lt;/i&gt; is.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="177"/>
        <source>I&apos;ve scanned in all file &quot;%1&quot; and didn&apos;t find a &lt;i&gt;load_mod_resource&lt;/i&gt; or &lt;i&gt;load_resource&lt;/i&gt; command that pointed me to a brf file that contained any such material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="180"/>
        <source>&lt;br&gt;- double check material name of the mesh&lt;br&gt;&lt;b&gt;or&lt;/b&gt;&lt;br&gt;- find the brf-file with the material, or create one&lt;br&gt;- add a line &lt;i&gt;load_&lt;b&gt;mod&lt;/b&gt;_resource&lt;/i&gt; in module.ini, with a text editor,&lt;br&gt;- (note the &lt;i&gt;mod&lt;/i&gt; part)!&lt;br&gt;- save module.ini&lt;br&gt;- come back, and refresh Module [f5]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="190"/>
        <source>I cannot find the file &quot;%1&quot; on disk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="192"/>
        <source>I&apos;ve looked in folders &lt;br&gt;%1&lt;br&gt; and &lt;br&gt;%2&lt;br&gt; and &lt;br&gt;%3&lt;br&gt; but it wasn&apos;t there...&lt;br&gt;Maybe it is was tiff texture? (I don&apos;t understand them).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="206"/>
        <source>I cannot understand the texture format of  file &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="215"/>
        <source>&lt;i&gt;I could not display the real texture because:&lt;/i&gt;&lt;br&gt;&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;&lt;br&gt;%2&lt;br&gt;&lt;br&gt;&lt;b&gt;Cure: &lt;/b&gt;%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="94"/>
        <location filename="../mainwindow.cpp" line="1323"/>
        <location filename="../mainwindow.cpp" line="1617"/>
        <location filename="../mainwindow.cpp" line="1641"/>
        <location filename="../mainwindow.cpp" line="2711"/>
        <location filename="../mainwindow.cpp" line="2723"/>
        <location filename="../mainwindow.cpp" line="3367"/>
        <location filename="../mainwindow.cpp" line="5131"/>
        <source>OpenBrf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="95"/>
        <source>%1 been modified.
Save changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="96"/>
        <source>Internal reference objects have</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="96"/>
        <source>The dataset has</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="432"/>
        <source>Set %1 mesh materials to &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="491"/>
        <source>Set time of frame %1 to %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="544"/>
        <source>CAnnot find skel_human, skel_dwarf and skel_orc in reference data.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="592"/>
        <source>Invalid frame %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="601"/>
        <source>%1 meshes shrunk around bones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="613"/>
        <source>Cannot find skel_human, skel_dwarf and skel_orc in reference data.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="759"/>
        <source>Set flag(s) to &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="928"/>
        <source>Stop editing reference data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="929"/>
        <source>Stop editing &quot;reference&quot; skeletons, animations &amp; meshes, that OpenBrf uses to display data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="931"/>
        <source>Edit reference data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="932"/>
        <source>Edit &quot;reference&quot; skeletons, animations &amp; meshes, that OpenBrf uses to display data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1080"/>
        <source>New %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1076"/>
        <source>new_%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1160"/>
        <source>Oops... no skin is currently available...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1165"/>
        <source>Skin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1169"/>
        <source>Select a skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1170"/>
        <source>Select a skin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1234"/>
        <source>Vertex unified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1324"/>
        <source>Mesh %1 will be 
split in %2 sub-meshes!.

Proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1295"/>
        <location filename="../mainwindow.cpp" line="1332"/>
        <source>Only one component found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1252"/>
        <source>object &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1254"/>
        <source>%1 objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1262"/>
        <source>Spatial extension of %7:

in X=%1 to %2
in Y=%3 to %4
in Z=%5 to %6

(data copied to clipboard)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1297"/>
        <location filename="../mainwindow.cpp" line="1334"/>
        <source>Mesh separated into %1 pieces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1361"/>
        <source>Autofixed rigid parts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1381"/>
        <source>Cannot merge these meshes
 (different number of frames,
 or skinned VS not skinned).
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2317"/>
        <source>Computed AO%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2317"/>
        <source>(in alpha channel)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1832"/>
        <source>Normals recomputed with %1% hard edges.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1185"/>
        <source>Select a skeleton
in the view panel first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1194"/>
        <source>Select an animation
in the view panel first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1887"/>
        <source>Softened %1 skinned meshes!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1907"/>
        <source>Stiffened %1 skinned meshes!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2001"/>
        <source>Shift animation timings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2002"/>
        <source>Current Interval: [%1 %2]
New interval: [%1+k %2+k]

Select k:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2045"/>
        <source>Extract Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2058"/>
        <source>Remove Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2081"/>
        <source>Cannot merge these animations
 (different number of bones).
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2108"/>
        <source>Cannot merge these meshes
 (different number of vertices, faces, points...).
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2211"/>
        <source>Skeleton %1 has no associated hit-box set. Canceled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2217"/>
        <source>Remove the hit-box associated to skeleton name %1?&lt;br /&gt;&lt;br /&gt;(this means that no skeleton named &apos;%1&apos; will have a hitbox, in this Module)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2535"/>
        <source>Transfer Skinning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2536"/>
        <source>Transfer skinning:
select a skinned mesh first,
then all target meshes.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2563"/>
        <source>Same skeleton:
reskeletonization canceled.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2573"/>
        <source>Different number of bones:
reskeletonization canceled.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2712"/>
        <source>Renaming %1...
new name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2724"/>
        <source>%3 common prefix for %1 %2...
new prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2724"/>
        <source>Changing the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2724"/>
        <source>Adding a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2810"/>
        <location filename="../mainwindow.cpp" line="2831"/>
        <source>%1: Select one skeleton with a hitbox first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2816"/>
        <source>%1: skeleton %2 has no kwown hitbox to copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2844"/>
        <location filename="../mainwindow.cpp" line="2855"/>
        <source>Wrong number of bones! (%1 in %2 VS %3 in %4). Cannot perform action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2864"/>
        <source>Cannot paste hitboxes: I don&apos;t have a hitboxes plus skeleton in clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2981"/>
        <source>Copyed prop code for %1 objects
(%2 with matching collison mesh)
on the clipboard.

Paste at will!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2984"/>
        <source>No prop mesh found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3117"/>
        <source>Copy Skinning into another mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3205"/>
        <source>Vertex number mismatch... using texture-coord matching instead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3332"/>
        <source>Cannot paste timings! Select *one* animated mesh or skel animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3345"/>
        <source>Pasted timings over %1 (animated) mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3351"/>
        <source>Pasted timings over %1 skeletal animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3354"/>
        <source>Cannot paste times over that</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3367"/>
        <source>To use paste modification mesh: firstcopy a 2 frames mesh. Then, select one or more destination meshes, and &quot;paste modification&quot;any vertex in any frame of the destination mesh that are in the same pos of frame 0,will be moved on the position of frame 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3485"/>
        <source>This will produce a vertex ani
with %1x%2 xyz positions+normals (%4 MB).

Proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3527"/>
        <source>Incompatible animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3556"/>
        <source>Incompatible skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3652"/>
        <source>Canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3720"/>
        <source>Added mesh %1 to set %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3741"/>
        <source>Animation %2 split in %1 chunks!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3743"/>
        <source>Animation could be auto-split (frames are too conescutive)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3750"/>
        <source>Select an &quot;actions.txt&quot; file (hint: it&apos;s in the module dir)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3751"/>
        <source>%1\actions.txt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3752"/>
        <source>Txt file(*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3755"/>
        <source>Split canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3763"/>
        <source>Nothing to split (or could not split).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3773"/>
        <source>Animation %2 split in %1 chunks -- new animation.txt file save in &quot;%3&quot;!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4186"/>
        <source>Cannot save reference file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4220"/>
        <source>Editing reference file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4245"/>
        <source>Cannot load %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4280"/>
        <source>You are saving a CommonRes file!
(i.e. not one specific of this module).

Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4292"/>
        <source>Cannot write file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4295"/>
        <source>File saved!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4430"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4432"/>
        <source>Resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4450"/>
        <source>Reference file saved!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4463"/>
        <source>M&amp;B Resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4463"/>
        <source>WarBand Resource v.1 (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4466"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4493"/>
        <source> [not in module.ini]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4497"/>
        <source>%1%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4499"/>
        <source>%1 - %2%3%4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4521"/>
        <source>Redone %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4553"/>
        <source>Undone %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4577"/>
        <source>Undo %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4580"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4586"/>
        <source>Redo %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4589"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4827"/>
        <source>%5 %1 brf files from module.ini of &quot;%3&quot;-- %2 msec total [%4 text/mat/shad]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4829"/>
        <source>scanned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4829"/>
        <source>ERRORS found while scanning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5266"/>
        <source>&amp;%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5305"/>
        <source>New Lod parameters set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5307"/>
        <source>Cancelled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5388"/>
        <source>Two-sided</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5389"/>
        <source>No Collision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5390"/>
        <source>No Shadow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5390"/>
        <source>Game won&apos;t use this collision object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5406"/>
        <source>Difficult</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5407"/>
        <source>Unwalkable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5435"/>
        <source>Collision objects flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5452"/>
        <source>Unknown (for props?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5452"/>
        <location filename="../mainwindow.cpp" line="5453"/>
        <location filename="../mainwindow.cpp" line="5454"/>
        <location filename="../mainwindow.cpp" line="5455"/>
        <location filename="../mainwindow.cpp" line="5457"/>
        <location filename="../mainwindow.cpp" line="5461"/>
        <location filename="../mainwindow.cpp" line="5462"/>
        <location filename="../mainwindow.cpp" line="5481"/>
        <location filename="../mainwindow.cpp" line="5569"/>
        <location filename="../mainwindow.cpp" line="5579"/>
        <source>Exact meaning of this flag is unknown.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5453"/>
        <location filename="../mainwindow.cpp" line="5455"/>
        <location filename="../mainwindow.cpp" line="5461"/>
        <location filename="../mainwindow.cpp" line="5481"/>
        <source>Unknown (for particles?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5454"/>
        <source>Unknown (plants?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5457"/>
        <source>Unknown (hairs and body parts?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5462"/>
        <source>Unknown (screen space?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5470"/>
        <source>R: (tangent space)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5470"/>
        <source>This flag is automatically set if mesh has tangent directions defined.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5471"/>
        <source>R: (Warband format)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5471"/>
        <source>This flag is automatically set for meshes in WB formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5479"/>
        <source>Pre-exponentiate colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5479"/>
        <source>Vertex colors will be pre-exponentiated (for gamma corrections) if this flag is set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5493"/>
        <source>Mesh flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5504"/>
        <location filename="../mainwindow.cpp" line="5506"/>
        <location filename="../mainwindow.cpp" line="5511"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5505"/>
        <source>Force hi-res</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5505"/>
        <source>By default, depending on the game settings, higher-res mipmap levels might by not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5507"/>
        <source>Languange dependent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5507"/>
        <source>If set, depending on the game language settings, this texture is substituted by the one found in the language folder (WB only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5508"/>
        <source>HDR only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5508"/>
        <source>If High-Dynamic-Ramge is off, this texture won&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5509"/>
        <source>No HDR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5509"/>
        <source>If High-Dynamic-Ramge is on, this texture won&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5526"/>
        <source>Clamp U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5526"/>
        <source>By default, texture U is set to wrap (horizontally tiled texture)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5527"/>
        <source>Clamp V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5527"/>
        <source>By default, texture V is set to wrap (vertically tiled texture)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5548"/>
        <source>Animation frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5548"/>
        <source>N. of frames of texture anim (append &quot;_0&quot;, &quot;_1&quot; ... to dds file names).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5550"/>
        <source>Size U (?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5551"/>
        <source>Size V (?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5545"/>
        <source>Texture flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="160"/>
        <source>There are %1 sets of hitboxes, for skeletons:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="162"/>
        <source>&lt;br /&gt;&lt;br /&gt;Save them inside %2?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1584"/>
        <source>Error loading line of file %2:

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1602"/>
        <source>Failed loading carry positions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2140"/>
        <location filename="../mainwindow.cpp" line="2152"/>
        <source>Select one or more animation using same number of bones first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2260"/>
        <source>Uniform color for mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2922"/>
        <source>%1 new BRF items found in clipboard...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2923"/>
        <source>Unusable data in clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3118"/>
        <source>Copy Skinning into another mesh:
- select one or more sample skinned mesh
- copy them (ctrl+C)
- then select one or more target meshes (skinned or otherwise),
- then paste skinning.

(works best if sample mesh is similar to target meshes)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3133"/>
        <source>Transferred skinning into %1 mesh(es) from %2 exemplar mesh(es).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3142"/>
        <source>Transferred skinning into %1 mesh(es) from skeleton &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3615"/>
        <source>I need to know from which skeleton to Unmount. Select a skeleton in the panel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3638"/>
        <source>Not a single skeleton found in reference data! Cancelling operation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="3679"/>
        <source>To apply carry position &apos;%1&apos;, I need to know the weapon lenght.
Use the ruler tool to tell me the lenght of weapon &apos;%2&apos;.

Activate ruler tool?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4173"/>
        <source>&lt;p&gt;You are saving into the generic OpenBRF reference file &lt;br&gt;&quot;%1&quot;&lt;/p&gt;&lt;p&gt;Would you rather save in the reference file &lt;i&gt;specific&lt;/i&gt; for Module %3&lt;br&gt;&quot;%2&quot;&lt;br&gt;?&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4286"/>
        <source>You are trying to save meshes with tangent directions in M&amp;B 1.011 file format.
Unfortunately, tangent directions can only be saved in Warband file format.
Tangent directions will not be saved...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4501"/>
        <source>%1 - editing internal reference data %3 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="4502"/>
        <source>(for [%1] mod)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5563"/>
        <source>No fog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5563"/>
        <source>This object must not be affected by fog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5564"/>
        <source>No Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5564"/>
        <source>This object won&apos;t be dynamically relit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5566"/>
        <source>No Z-write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5566"/>
        <source>Rendering object leaves the depth buffer unaffected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5567"/>
        <source>No depth Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5567"/>
        <source>Object ignores the depth test: i.e. it will be always drawn over others.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5568"/>
        <source>Specular enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5568"/>
        <source>Specular reflections are enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5569"/>
        <location filename="../mainwindow.cpp" line="5579"/>
        <source>Unknown (for alpha test?)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5612"/>
        <source>Alpha test:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5612"/>
        <source>Alpha testing (for cutouts). Pixels more transparent than a given number will be not drawn.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5638"/>
        <source>pixel shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5638"/>
        <source>requires config setting use_pixel_shaders and video card PS 1.1 capability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5639"/>
        <source>mid quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5639"/>
        <source>requires config setting shader_quality &gt; 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5640"/>
        <source>hi quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5640"/>
        <source>requires config setting shader_quality &gt; 1 and some additional video card PS 2.0a/b capabilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5667"/>
        <source>Shader Requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5684"/>
        <source>specular enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5684"/>
        <source>enables specular light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5686"/>
        <source>static_lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5686"/>
        <source>meshes using this shader will simulate lighting by vertex painting (static, on scene creation)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5693"/>
        <source>preshaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5693"/>
        <source>uses preshaded technique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5694"/>
        <source>uses instancing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5694"/>
        <source>shader receives instance data as input (TEXCOORD1..4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5696"/>
        <source>biased</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5696"/>
        <source>used for shadowmap bias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5713"/>
        <source>uses pixel shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5713"/>
        <source>this shader uses pixel shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5714"/>
        <source>uses HLSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5714"/>
        <source>if not set the FFP will be used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5715"/>
        <source>uses normal map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5715"/>
        <source>shader receives binormal and tangent as input (TANGENT, BINORMAL)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5716"/>
        <source>uses skinning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5716"/>
        <source>shader receives skinning data as input (BLENDWEIGHTS, BLENDINDICES)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5723"/>
        <source>Shader flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5570"/>
        <source>Uniform lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="115"/>
        <source>Skeleton hitboxes have been modified.&lt;br/&gt;Save changes in /Data/skeleton_bodies.xml?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="146"/>
        <source>Error: could not make missing folder &apos;Data&apos; in module folder:
 %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="163"/>
        <source>&lt;br /&gt;&lt;br /&gt;A backup will be saved in %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="177"/>
        <source>Error saving hitbox data:

%1

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="185"/>
        <source>Saved hitboxes (with the other metadata) for %1 skeletons inside
file %2

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1668"/>
        <source>No mesh found to learn how to femininize an armour.

You must select meshes with feminine frame, and I&apos;ll try to learn the way to build a femenine frame from a given armour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1676"/>
        <source>Select a emphasis factor between -100% and +100%

zero =&gt; normal.
positive =&gt; stronger effect.
negative =&gt; milder effect 

(default: +15%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1681"/>
        <source>Select amount of extra breastification in mm
(default: 13mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1691"/>
        <source>Learnt a custom way to femininize an armour
from %1 examples!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1694"/>
        <source>Canceled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1714"/>
        <source>Warning: mesh %1 has already a feminine frame %2.

Overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5550"/>
        <location filename="../mainwindow.cpp" line="5551"/>
        <source>Unclear meaining, usually only set for facial textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5573"/>
        <source>Blend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5573"/>
        <source>Enable alpha-blending (for semi-transparencty)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5574"/>
        <source>Blend add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5574"/>
        <source>Alpha-blend function: add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5575"/>
        <source>Blend multiply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5575"/>
        <source>Alpha-blend function: mulitply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5576"/>
        <source>Blend factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5576"/>
        <source>Alpha-blend function: factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5582"/>
        <source>Render 1st</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5583"/>
        <source>Origin at camera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5584"/>
        <source>LoD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5584"/>
        <source>If set, this material is optimized for LODs&gt;1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5596"/>
        <source>Invert bumpmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5596"/>
        <source>If set, bumpmap should be considered inverted on Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5609"/>
        <source>Render order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5609"/>
        <source>Determines what is rendered first (neg number), or later (pos numbers)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="5606"/>
        <source>Material flags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MyTableModel</name>
    <message>
        <location filename="../tablemodel.cpp" line="84"/>
        <source>HEADER</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTextBrowser</name>
    <message>
        <location filename="../iniData.cpp" line="133"/>
        <source>cannot open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="141"/>
        <source>expected &apos;%1&apos;,
got &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="145"/>
        <source>unexpected end of file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="175"/>
        <source>cannot read token n. %1 from:
 &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="182"/>
        <location filename="../iniData.cpp" line="190"/>
        <source>expected number istead of &apos;%1&apos; (token %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="183"/>
        <source>wrong number : %1 (not in [%2, %3]) (token %4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="200"/>
        <source>Error reading file &apos;%1&apos;,
at line %3:
%2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="242"/>
        <source>%1 %2 from &apos;%3&apos; &lt;font size=-1&gt;(&apos;%4&apos;, &apos;%5&apos;, &apos;%6&apos;...)&lt;/font&gt;

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="691"/>
        <source>%6 &lt;a href=&quot;#%1.%2.%3&quot;&gt;%4&lt;/a&gt; (in %5)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="706"/>
        <source>&lt;b&gt;File-not-found:&lt;/b&gt; can&apos;t find image file for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="711"/>
        <source>&lt;b&gt;File-not-found:&lt;/b&gt; can&apos;t find frame &quot;%2&quot; for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="759"/>
        <source>&lt;b&gt;Missing:&lt;/b&gt; %1 uses unknown %2 &lt;u&gt;%3&lt;/u&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="765"/>
        <source>&lt;b&gt;Ordering problem:&lt;/b&gt; %1 uses %2, which appears later in &lt;i&gt;module.ini&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="788"/>
        <source>&lt;h1&gt;Module &lt;b&gt;%1&lt;/b&gt;&lt;/h1&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="794"/>
        <source>&lt;h2&gt;Original BRF files: %1&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="796"/>
        <source>&lt;h2&gt;CommonRes BRF files: %1&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="804"/>
        <source>&lt;i&gt;(used+unused)&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="805"/>
        <source>&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="811"/>
        <source>&lt;h2&gt;Txt data:&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1313"/>
        <source>&lt;b&gt;Missing in txt:&lt;/b&gt; cannot find %1 &lt;u&gt;%2&lt;/u&gt;, referred in &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1392"/>
        <source>&lt;b&gt;File-Not-Found:&lt;/b&gt; could not read brf file &lt;u&gt;%1&lt;/u&gt;, listed in module.ini file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1395"/>
        <source>&lt;b&gt;File-Format Error:&lt;/b&gt; could not read brf file &lt;u&gt;%1&lt;/u&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTextBrowser::QTextBrowser</name>
    <message>
        <location filename="../iniData.cpp" line="974"/>
        <source>&lt;i&gt;more errors to follow...&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="996"/>
        <source>&lt;i&gt;[0 results]&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="732"/>
        <source>&lt;b&gt;Duplicate:&lt;/b&gt; %1 was already defined in file %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Selector</name>
    <message>
        <location filename="../selector.cpp" line="12"/>
        <source>&amp;Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="13"/>
        <source>Te&amp;xture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="14"/>
        <source>&amp;Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="15"/>
        <source>Mat&amp;erial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="16"/>
        <source>S&amp;keleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="17"/>
        <source>&amp;Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="18"/>
        <source>&amp;Collision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="59"/>
        <source>Split sequence following the action.txt file. A new &quot;action [after split].txt&quot; file is also produced, which use the new animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="61"/>
        <source>Auto-split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="62"/>
        <source>Auto-split sequence into its separated chunks, separating it at lasge gaps in frames.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="65"/>
        <source>Extract interval...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="66"/>
        <source>Extract an animation from an interval of times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="69"/>
        <source>Mirror this animation over the X axis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="71"/>
        <source>Remove interval...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="72"/>
        <source>Remove an interval of times from the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="74"/>
        <source>Merge animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="75"/>
        <source>Merge two animations into one -- intervals must be right!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="82"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="87"/>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="89"/>
        <source>next tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="94"/>
        <source>left tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="101"/>
        <source>Move this object upward in the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="107"/>
        <source>Move this object one step down in the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="112"/>
        <source>Add to reference animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="113"/>
        <source>Add this animation to reference animations (to use it later to display skinned meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="115"/>
        <source>Add to reference skeletons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="116"/>
        <source>Add this animation to reference skeletons (to use it later for animations).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="119"/>
        <source>set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="120"/>
        <source>Add this mesh to reference skins (to use it later to display animations).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="145"/>
        <source>&lt;none&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="150"/>
        <source>mod file &lt;%1&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="152"/>
        <source>mod file &lt;%1&gt; (indirectly)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="156"/>
        <source>&lt;no .txt file&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="158"/>
        <source>&lt;core engine&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="160"/>
        <source>&lt;core engine&gt; (indirectly)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="163"/>
        <source>&lt;not in module.ini&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="165"/>
        <source>&lt;save file to find out&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="168"/>
        <source>(not computed: compute now)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="174"/>
        <source>Info on mesh import/export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="177"/>
        <source>Export this model (or this frame) as a 3D static mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="180"/>
        <source>Export this model as a mesh with vertex animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="183"/>
        <source>Export this group of models in a single OBJ.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="184"/>
        <source>Export all meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="185"/>
        <source>Export each of these models as separate OBJs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="188"/>
        <source>Export each of these collison bodies as separate files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="191"/>
        <source>Export this model (or this frame) as a skinned mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="194"/>
        <source>Export this skeleton (as a set of nude bones).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="196"/>
        <source>Export this skeleton (as a skinned skin).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="197"/>
        <source>Export a skin for this ani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="198"/>
        <source>Export a skinned skin which can be used for this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="200"/>
        <location filename="../selector.cpp" line="203"/>
        <source>Convert into vertex animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="201"/>
        <source>Convert skeletal animation into a vertex animation using current skin and skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="204"/>
        <source>Convert skinned mesh into a vertex animation using current animation and skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="207"/>
        <source>Export this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="218"/>
        <source>Adapt this skinned mesh to a new skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="223"/>
        <source>Transfer skinning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="224"/>
        <source>Copy skinning from one mesh to another</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="235"/>
        <source>Roto-translate-rescale...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="238"/>
        <source>Rescale...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="241"/>
        <source>(no object selected)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="245"/>
        <source>Shift time interval...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="253"/>
        <source>Recompute normals...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="256"/>
        <source>Clean redundant vert/pos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="257"/>
        <source>Removes any unused vertices or positions and merge identical ones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="274"/>
        <source>Mount on one bone...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="279"/>
        <location filename="../selector.cpp" line="282"/>
        <source>Back-faces: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="285"/>
        <source>Set per vertex color as ambient occlusion (globlal lighting) %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="287"/>
        <source>Copy colors from texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="288"/>
        <source>Set per vertex color as texture colors %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="296"/>
        <source>Get dimensions...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="314"/>
        <source>skinning (freeze current pose)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="315"/>
        <source>Discard skinning, but freeze mesh in its current pose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="317"/>
        <source>skinning (un-mount from bone)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="318"/>
        <source>Discard skinning, and move object back at origin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="320"/>
        <source>Merge as frames in a vertex ani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="321"/>
        <source>Merge these meshes, in their current order, as frames in a mesh ani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="299"/>
        <source>Separate all frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="300"/>
        <source>Split all frames, making 1 mesh per frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="302"/>
        <source>Color uniform...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="303"/>
        <source>Set per vertex color as a uniform color %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="308"/>
        <source>Tune colors HSB...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="311"/>
        <source>Discard hit-boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="312"/>
        <source>Discard hit-box set associated to skeletons with this name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="326"/>
        <source>Discard skinning (per-verex bone attachments)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="332"/>
        <source>Discard vertex animation (keep only current frame)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="336"/>
        <source>Make a skeleton-modification mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="337"/>
        <source>Modify from a skeleton-modification mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="445"/>
        <source>[Right-Click]: tools for %1. Multiple selections with [Shift] or [Ctrl].</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="639"/>
        <source>Group rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="651"/>
        <source>Used by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="68"/>
        <location filename="../selector.cpp" line="232"/>
        <source>Mirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="58"/>
        <source>Split via action.txt...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="77"/>
        <location filename="../selector.cpp" line="639"/>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="99"/>
        <source>Move up in the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="105"/>
        <source>Move down in the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="172"/>
        <source>Export...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="176"/>
        <source>Export static mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="179"/>
        <source>Export vertex ani...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="182"/>
        <source>Export combined mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="187"/>
        <source>Export all...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="190"/>
        <source>Export skinned mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="193"/>
        <source>Export (nude) skeleton...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="195"/>
        <source>Export skeleton with skin...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="206"/>
        <source>Export animation...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="209"/>
        <source>Reimport mesh...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="210"/>
        <location filename="../selector.cpp" line="212"/>
        <source>Reimport this mesh from file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="211"/>
        <source>Reimport animation...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="213"/>
        <source>Reimport collision body...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="214"/>
        <source>Reimport this collision mesh from file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="217"/>
        <location filename="../selector.cpp" line="220"/>
        <source>Reskeletonize...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="221"/>
        <source>Adapt this animation to a new skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="226"/>
        <source>Make skinning stiffer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="227"/>
        <source>Make the skinning of selected mesh(es) somewhat rigidier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="229"/>
        <source>Make skinning softer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="230"/>
        <source>Make the skinning of selected mesh(es) somewhat softer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="233"/>
        <source>Mirror this object on the X axis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="236"/>
        <source>Apply a geometric transform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="239"/>
        <source>Rescale this object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="246"/>
        <source>Shift a time interval for this animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="248"/>
        <source>Make quad-dominant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="249"/>
        <source>Try to merge most triangles into fewer quads (more efficient!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="250"/>
        <source>Combine collision objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="251"/>
        <source>Make a combined collision obj. unifying these objs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="254"/>
        <source>Recompute normals for this model, and unify pos and vertices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="259"/>
        <source>Transfrom texture coords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="260"/>
        <source>Translates/Scales/Flips UV coords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="262"/>
        <source>Quick fix skinning of rigid-parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="263"/>
        <source>Attempts to fix skinning of small-parts, making them rigid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="265"/>
        <source>Split into connected sub-meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="266"/>
        <source>Create a separate mesh for each connected component of this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="268"/>
        <source>Combine meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="269"/>
        <source>Make a combined mesh unifying these meshes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="271"/>
        <source>Make a collision object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="272"/>
        <source>Turn this mesh(es) into a combined Collision object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="275"/>
        <source>Put this mesh on top of a single skeleton bone.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="277"/>
        <source>remove all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="278"/>
        <source>Remove all faces that are backfacing (e.g. in beard meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="280"/>
        <source>add (x2 faces)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="281"/>
        <source>Duplicate all faces: for each current face, add a backfacing face.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="284"/>
        <source>Color with Ambient Occlusion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="290"/>
        <source>Add femininized frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="291"/>
        <source>Build a feminine frame for this armour(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="293"/>
        <source>Compute LODs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="294"/>
        <source>Tries to compute a LOD pyramid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="297"/>
        <source>Tell me the dimension of selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="305"/>
        <source>Recompute tangent dirs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="306"/>
        <source>(Tangent dirs are needed for bump-mapping)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="309"/>
        <source>Then Hue Saturation and Brightness of per-vertex colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="323"/>
        <source>per-vertex color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="324"/>
        <source>Reset per-vertex coloring (i.e. turn all full-white)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="325"/>
        <source>skinning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="327"/>
        <source>tangent directions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="328"/>
        <source>Remove tangent directions (saves space, they are needed mainly for bumbmapping)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="329"/>
        <source>normals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="330"/>
        <source>Disregard normals, so to merge more vertices (and use less of them)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="331"/>
        <source>vertex animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="450"/>
        <source>[Right-Click]: tools for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="775"/>
        <source>Backfacing faces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="780"/>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="835"/>
        <source>Add to reference skins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="838"/>
        <source>to Skin Set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="842"/>
        <source>to Skin Set %1 [new set]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>askModErrorDialog</name>
    <message>
        <location filename="../askModErrorDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.ui" line="45"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.ui" line="81"/>
        <source>look in commonres too</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>askSkelPairDialog</name>
    <message>
        <location filename="../askSkelPairDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelPairDialog.ui" line="65"/>
        <source>from Skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelPairDialog.ui" line="81"/>
        <source>to Skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelPairDialog.ui" line="97"/>
        <location filename="../askSkelPairDialog.ui" line="148"/>
        <source>bones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelPairDialog.ui" line="110"/>
        <location filename="../askSkelPairDialog.ui" line="129"/>
        <source>Number of bones composing this skeleton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelPairDialog.ui" line="161"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Readapting animation(s) to a different skeleton.&lt;span style=&quot; font-style:italic;&quot;&gt;&lt;br /&gt;Bone matching is done by name.&lt;br /&gt;Missing bones are fixed in positions, as in&amp;quot;from&amp;quot; skeleton.&lt;br /&gt;Extra bones are discarded from ani.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>askTexturenameDialog</name>
    <message>
        <location filename="../askTexturenameDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.ui" line="42"/>
        <source>name(s):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.ui" line="58"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
