#ifndef BRFUITOKEN_H
#define BRFUITOKEN_H
#include "QString.h"
#include "brfToken.h"

extern char * tokenTabName[N_TOKEN];
extern char * tokenFullName[N_TOKEN];
extern char * tokenPlurName[N_TOKEN];


#endif // BRFUITOKEN_H
