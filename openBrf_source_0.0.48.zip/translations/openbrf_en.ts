<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AskBoneDialog</name>
    <message>
        <location filename="../askBoneDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="62"/>
        <source>Reference skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="78"/>
        <source>Bone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="99"/>
        <source>This mesh is not rigged:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="117"/>
        <source>Select a skeleton and a bone to attach this mesh to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="130"/>
        <source>at origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="143"/>
        <source>in the correct final position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askBoneDialog.ui" line="156"/>
        <source>Piece currently centered:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskCreaseDialog</name>
    <message>
        <location filename="../askCreaseDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="64"/>
        <source>Recomputing normals:
how many hard edges?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="83"/>
        <source>all edges soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="104"/>
        <source>all edges hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askCreaseDialog.ui" line="120"/>
        <source>keep texture
seams hard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskFlagsDialog</name>
    <message>
        <location filename="../askFlagsDialog.cpp" line="39"/>
        <source>unused?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.cpp" line="47"/>
        <source>reserved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="42"/>
        <source>Flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askFlagsDialog.ui" line="95"/>
        <source>show all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2682"/>
        <source>No fog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2683"/>
        <source>No Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2685"/>
        <source>No Z-write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2686"/>
        <source>No depth Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2687"/>
        <source>Specular enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2688"/>
        <source>Alpha test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2689"/>
        <source>Uniform lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2692"/>
        <source>Blend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2693"/>
        <source>Blend add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2694"/>
        <source>Blend multiply *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2695"/>
        <source>Blend factor **</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2696"/>
        <source>Alpha test 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2697"/>
        <source>Alpha test 128</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2698"/>
        <source>Alpha test 256 *</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2701"/>
        <source>Render 1st</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2702"/>
        <source>Origin at camera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2703"/>
        <source>LoD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2714"/>
        <source>Invert bumpmap</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskModErrorDialog</name>
    <message>
        <location filename="../askModErrorDialog.cpp" line="35"/>
        <source>Look for:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="42"/>
        <source>Any kind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="52"/>
        <source>Searching for errors...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="54"/>
        <source>&lt;i&gt;scanning data...&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="90"/>
        <source>Found 0 errors in module!</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../askModErrorDialog.cpp" line="92"/>
        <source>Found %n%1 error:</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="106"/>
        <source>&lt;i&gt;[ready]&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="124"/>
        <source>More errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="130"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.cpp" line="145"/>
        <source>OpenBrf -- Module %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskNewUiPictureDialog</name>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="42"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;This will create: a Mesh, a Material, and a Texture&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;which can be used ingame as a 2D decoration &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-style:italic;&quot;&gt;in the background of menus.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="61"/>
        <source>Size and Pos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="76"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="83"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="102"/>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="112"/>
        <source>Lower-left
corner: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="120"/>
        <source>Actual pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="127"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="143"/>
        <source>in pixels, on a
1024x768 sceen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="272"/>
        <source>replace existing Mat.
Mesh, and Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="157"/>
        <source>in % of screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="170"/>
        <source>Set fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="184"/>
        <source>Picture name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="196"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="220"/>
        <source>Overlay mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="232"/>
        <source>Darken (multiply)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="245"/>
        <source>Normal (alpha blend)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.ui" line="258"/>
        <source>Substitute (no alpha)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askNewUiPictureDialog.cpp" line="138"/>
        <source>Select a texture for a menu background file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskSelectBRFDialog</name>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="31"/>
        <source>In
Module
folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="64"/>
        <source>Not
included in
module.ini:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="81"/>
        <source>In
Comm Res
folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="115"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSelectBrfDialog.ui" line="122"/>
        <source>Count used</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskSkelDialog</name>
    <message>
        <location filename="../askSkelDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="42"/>
        <source>cbSkelTo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="65"/>
        <source>From (current skeleton):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="81"/>
        <source>To (destination skeleton):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="102"/>
        <source>Change geometry of meshes currently rigged for a skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="120"/>
        <source>to make it follow a new skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="133"/>
        <source>Put result in:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="145"/>
        <source>same mesh (overwrite)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="158"/>
        <source>new mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="171"/>
        <source>new vertex-ani frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="185"/>
        <source>Method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="197"/>
        <source>generic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askSkelDialog.ui" line="210"/>
        <source>humanoids</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskTexturenameDialog</name>
    <message>
        <location filename="../askTexturenameDialog.cpp" line="62"/>
        <source>Select a texture file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskTransformDialog</name>
    <message>
        <location filename="../askTransformDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="42"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="120"/>
        <location filename="../askTransformDialog.ui" line="256"/>
        <location filename="../askTransformDialog.ui" line="398"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="136"/>
        <location filename="../askTransformDialog.ui" line="272"/>
        <location filename="../askTransformDialog.ui" line="414"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="152"/>
        <location filename="../askTransformDialog.ui" line="288"/>
        <location filename="../askTransformDialog.ui" line="430"/>
        <source>Z:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="169"/>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="305"/>
        <source>Scale %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTransformDialog.ui" line="446"/>
        <source>Uniform</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AskUnrefTextureDialog</name>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="25"/>
        <source>Unused DDS files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="40"/>
        <source>Note: these are the files which are not included
 in any BRF file as textures.
They will not be even loaded by the game.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askUnrefTextureDialog.ui" line="68"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GLWidget</name>
    <message>
        <location filename="../glwidgets.cpp" line="734"/>
        <source>Scene mode: navigate with mouse and WASD (levitate with wheel, zoom in with shift)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="739"/>
        <source>Helmet mode: for objects with vertical Z axis, like M&amp;B helmets or weapons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../glwidgets.cpp" line="741"/>
        <source>Default mode: rotate objects with mouse, zoom in/out with wheel.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GuiPanel</name>
    <message>
        <location filename="../guipanel.cpp" line="276"/>
        <source>Mesh-set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="26"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="44"/>
        <location filename="../guipanel.ui" line="986"/>
        <location filename="../guipanel.ui" line="1234"/>
        <location filename="../guipanel.ui" line="1473"/>
        <location filename="../guipanel.ui" line="1865"/>
        <location filename="../guipanel.ui" line="1919"/>
        <location filename="../guipanel.ui" line="2227"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="59"/>
        <source>Set material used by this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="75"/>
        <source>Click to follow material (if known in module.ini).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="78"/>
        <source>&lt;a href=&quot;link&quot;&gt;Material&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="97"/>
        <source>Number of vertices of this mesh, including seams.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="119"/>
        <source>Mesh flags (unknown meaning)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="122"/>
        <location filename="../guipanel.ui" line="1020"/>
        <location filename="../guipanel.ui" line="2023"/>
        <source>000000000000; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="138"/>
        <location filename="../guipanel.ui" line="998"/>
        <location filename="../guipanel.ui" line="1660"/>
        <location filename="../guipanel.ui" line="2001"/>
        <source>Flags:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="160"/>
        <source>Diffuse texture name (depends on material)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="179"/>
        <source>Texture:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="198"/>
        <location filename="../guipanel.ui" line="2530"/>
        <source>faces:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="217"/>
        <source>Number of triangles of this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="236"/>
        <source>vert:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="255"/>
        <source>Number of different X,Y, Z position of this mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="277"/>
        <source>pos:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="296"/>
        <source>Number of frames (&gt;1 for vertex animated meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="321"/>
        <source>frames:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="346"/>
        <source>Time of frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="384"/>
        <source>Time of this frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="403"/>
        <location filename="../guipanel.ui" line="1458"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="424"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="463"/>
        <source>Skin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="479"/>
        <source>Select a reference skin to show this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="508"/>
        <source>Show no color (all white).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="511"/>
        <source>No Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="524"/>
        <source>Use vertex color as defined in the BRF file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="527"/>
        <source>Vertex Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="543"/>
        <source>Enable disable lighting,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="546"/>
        <source>Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="562"/>
        <source>Show rigging by coloring mesh according to attached bones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="565"/>
        <source>Rigging Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="578"/>
        <source>Show/hide wireframe.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="581"/>
        <source>WireFrame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="594"/>
        <source>Enable disable texture mapping.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="597"/>
        <source>Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="600"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="626"/>
        <source>Show/hide a floor at Y = 0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="629"/>
        <source>Floor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="655"/>
        <location filename="../guipanel.ui" line="674"/>
        <source>Current weapon reach.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="696"/>
        <source>Show ruler to measure weapon reach.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="699"/>
        <source>Ruler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="725"/>
        <source>Select a reference animation to view rigged meshes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="738"/>
        <source>Animation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="764"/>
        <source>Skeleton:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="780"/>
        <source>Select a reference skeleton (e.g. human or horse)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="808"/>
        <source>Pause the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="811"/>
        <source>||</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="829"/>
        <source>Play the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="832"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="850"/>
        <source>Stop the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="853"/>
        <source>[]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="871"/>
        <source>Next frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="874"/>
        <source>&gt;|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="892"/>
        <source>Prev frame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="895"/>
        <source>|&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="918"/>
        <source>Show RGB channel of texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="921"/>
        <source>&amp;RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="937"/>
        <source>Show alpha transparency (alpha = 0 means transparent).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="940"/>
        <source>Alpha &amp;Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="953"/>
        <source>Show alpha channel of textures.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="956"/>
        <source>&amp;Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1017"/>
        <source>Texture flags (unknown meaning)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1039"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1055"/>
        <source>res:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1087"/>
        <source>Space taken on disk (compressed).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1122"/>
        <source>KBytes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1154"/>
        <source># mipmap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1176"/>
        <source>Format of dds file on disk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1195"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1211"/>
        <source>Click to go back to the material.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1217"/>
        <location filename="../guipanel.ui" line="1848"/>
        <location filename="../guipanel.ui" line="2210"/>
        <source>(&lt;a href=&quot;link&quot;&gt;back&lt;/a&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1246"/>
        <source>First frame of the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1265"/>
        <source>Number of bones this animation is made for.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1284"/>
        <source>Number of frames in this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1303"/>
        <source>Last frame of the animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1322"/>
        <location filename="../guipanel.ui" line="1877"/>
        <source># bones:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1338"/>
        <source># frames:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1354"/>
        <source>interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1370"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1395"/>
        <source>time of frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1408"/>
        <source>Frame number (1 = first)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1439"/>
        <source>Time of this frame (must always be increasing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1485"/>
        <source>Shader used by this material.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1498"/>
        <source>Main diffuse (RGB color) texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1511"/>
        <source>Second diffuse (RGB color) texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1524"/>
        <source>Bumpmap texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1537"/>
        <source>Environment map texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1550"/>
        <source>Red component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1563"/>
        <source>Green component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1576"/>
        <source>Blue component of specular color.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1589"/>
        <source>Spec RGB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1605"/>
        <source>Specular map texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1618"/>
        <source>Coeff:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1634"/>
        <source>Specular coefficient (glossiness). Higher = smaller brighter reflections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1647"/>
        <source>Flags (click on button to edit bits)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1676"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1689"/>
        <source>Rend.Ord:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1705"/>
        <source>Rendering order (negative = soonest)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1724"/>
        <source>Click to open file containing shader.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1727"/>
        <source>&lt;a href=&quot;link&quot;&gt;Shader&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1743"/>
        <location filename="../guipanel.ui" line="1762"/>
        <source>Click to open file containing this texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1746"/>
        <source>&lt;a href=&quot;link&quot;&gt;DiffuseA&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1765"/>
        <source>&lt;a href=&quot;link&quot;&gt;DiffuseB&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1781"/>
        <source>Click to open file containing this bumpmap,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1784"/>
        <source>&lt;a href=&quot;link&quot;&gt;Bump&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1800"/>
        <source>Click to open file containing this environment map.</source>
        <oldsource>Click to open file containing this enviornment map.</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1803"/>
        <source>&lt;a href=&quot;link&quot;&gt;Enviro&lt;/a&gt;:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1819"/>
        <source>Click to open file containing this specular map.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1822"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;link&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;Specular&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1842"/>
        <source>Click to go back to the mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1893"/>
        <source>Number of bones composing this skeleton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1931"/>
        <source>Technique:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1947"/>
        <location filename="../guipanel.ui" line="1956"/>
        <source>Technique: name of the &quot;technique&quot; inside mb.fx file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1969"/>
        <source>Fallback:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="1985"/>
        <source>Which other shader to use if requirements are not met.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2020"/>
        <source>Shader flags (no known meaning).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2042"/>
        <source>Specify if a DDX version is required here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2058"/>
        <source>Requires:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2074"/>
        <source>texture access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2086"/>
        <source>map:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2142"/>
        <source>colorOp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2158"/>
        <source>alphaOp:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2174"/>
        <location filename="../guipanel.ui" line="2556"/>
        <source>flags:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2194"/>
        <source>Texture access index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2242"/>
        <source>Select a subpiece composing this collision object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2258"/>
        <source>piece</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2333"/>
        <source>axisA:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2359"/>
        <source>axisB:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2433"/>
        <source>radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2488"/>
        <source>verts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2595"/>
        <source>sign:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../guipanel.ui" line="2641"/>
        <source>piece list:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IniData</name>
    <message>
        <location filename="../iniData.cpp" line="640"/>
        <source>&lt;b&gt;File-not-found:&lt;/b&gt; can&apos;t find texture file for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="659"/>
        <source>&lt;b&gt;Duplicate:&lt;/b&gt; %1 was already defined in file %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="686"/>
        <source>&lt;b&gt;Missing:&lt;/b&gt; %1 uses unknown %2 &lt;u&gt;%3&lt;/u&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="692"/>
        <source>&lt;b&gt;Ordering problem:&lt;/b&gt; %1 uses %2, which appears later in &lt;i&gt;module.ini&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="715"/>
        <source>&lt;h1&gt;Module &lt;b&gt;%1&lt;/b&gt;&lt;/h1&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="721"/>
        <source>&lt;h2&gt;Original BRF files: %1&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="723"/>
        <source>&lt;h2&gt;CommonRes BRF files: %1&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="731"/>
        <source>&lt;i&gt;(used+unused)&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="732"/>
        <source>&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="738"/>
        <source>&lt;h2&gt;Txt data:&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1131"/>
        <source>&lt;b&gt;Missing in txt:&lt;/b&gt; cannot find %1 &lt;u&gt;%2&lt;/u&gt;, defined in &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1208"/>
        <source>&lt;b&gt;File-Not-Found:&lt;/b&gt; could not read brf file &lt;u&gt;%1&lt;/u&gt;, listed in module.ini file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="1211"/>
        <source>&lt;b&gt;File-Format Error:&lt;/b&gt; could not read brf file &lt;u&gt;%1&lt;/u&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IniData::ModuleTxtNameList</name>
    <message>
        <location filename="../iniData.cpp" line="223"/>
        <source>%1 %2 from &apos;%3&apos; &lt;font size=-1&gt;(&apos;%4&apos;, &apos;%5&apos;, &apos;%6&apos;...)&lt;/font&gt;

</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../main_ImpExp.cpp" line="18"/>
        <source>Select Module folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="23"/>
        <source>Not a recognized module folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="39"/>
        <location filename="../main_ImpExp.cpp" line="71"/>
        <location filename="../main_ImpExp.cpp" line="91"/>
        <location filename="../main_ImpExp.cpp" line="117"/>
        <location filename="../main_ImpExp.cpp" line="139"/>
        <location filename="../main_ImpExp.cpp" line="172"/>
        <location filename="../main_ImpExp.cpp" line="189"/>
        <location filename="../main_ImpExp.cpp" line="202"/>
        <location filename="../main_ImpExp.cpp" line="242"/>
        <location filename="../main_ImpExp.cpp" line="262"/>
        <location filename="../main_ImpExp.cpp" line="292"/>
        <location filename="../main_ImpExp.cpp" line="299"/>
        <location filename="../main_ImpExp.cpp" line="324"/>
        <location filename="../main_ImpExp.cpp" line="342"/>
        <location filename="../main_ImpExp.cpp" line="504"/>
        <location filename="../main_ImpExp.cpp" line="534"/>
        <location filename="../main_ImpExp.cpp" line="555"/>
        <location filename="../main_ImpExp.cpp" line="597"/>
        <location filename="../main_ImpExp.cpp" line="607"/>
        <location filename="../main_ImpExp.cpp" line="725"/>
        <location filename="../main_ImpExp.cpp" line="784"/>
        <location filename="../main_ImpExp.cpp" line="839"/>
        <location filename="../main_ImpExp.cpp" line="857"/>
        <source>Open Brf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="40"/>
        <source>Cannot open file for writing;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="61"/>
        <source>Select a folder to export all meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="72"/>
        <source>Cannot open file %1 for writing;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="92"/>
        <location filename="../main_ImpExp.cpp" line="140"/>
        <location filename="../main_ImpExp.cpp" line="190"/>
        <source>Cannot export animation without a proper skeleton!
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="118"/>
        <source>Cannot export rigged mesh:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="173"/>
        <source>Cannot export rest-pose:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="203"/>
        <source>Cannot export animation:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="243"/>
        <source>Cannot export skeleton:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="263"/>
        <source>Cannot export control mesh in file 
&quot;%1&quot;

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="275"/>
        <location filename="../main_ImpExp.cpp" line="575"/>
        <source>mesh file (*.obj *.ply *.off *.stl *.dae)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="293"/>
        <source>Cannot read mesh!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="300"/>
        <source>Modification of skeleton with mesh: fail!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="325"/>
        <source>Cannot write file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="338"/>
        <source>Quake 3 vertex animation (*.MD3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="343"/>
        <source>Error exporting MD3 file
: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="425"/>
        <source>Import file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="431"/>
        <location filename="../main_ImpExp.cpp" line="449"/>
        <source>Import canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="443"/>
        <source>Import files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="481"/>
        <source>Export file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="482"/>
        <source>%1\%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="486"/>
        <source>Export canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="505"/>
        <source>Cannot import file %1:
%3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="527"/>
        <source>Warband or M&amp;B resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="535"/>
        <source>Cannot import file %1

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="547"/>
        <source>mesh file (*.obj)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="556"/>
        <location filename="../main_ImpExp.cpp" line="598"/>
        <source>Cannot import file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="608"/>
        <source>Cannot import file %1

(error: %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="638"/>
        <location filename="../mainwindow.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="639"/>
        <source>Mesh &quot;%1&quot; has multiple materials\objects.
Import a separate mesh per material\object?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="654"/>
        <source>Imported mesh &quot;%1&quot;--- normals:%2 colors:%3 texture_coord:%4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="672"/>
        <source>Import vertex animation frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="673"/>
        <source>Frist select a mesh
to add a frame to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="682"/>
        <source>Import failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="692"/>
        <location filename="../mainwindow.cpp" line="1432"/>
        <source>Vertex number mismatch... using texture-coord matching instead of vertex-ordering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="707"/>
        <location filename="../mainwindow.cpp" line="1439"/>
        <source>Added frame %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="709"/>
        <source>Added frames %1..%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="726"/>
        <source>Cannot import animation:
 %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="744"/>
        <source>Found no time value in SMD file, so I added them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="785"/>
        <source>Cannot import skeleton:
%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="797"/>
        <source>Imported skeleton &quot;%1&quot;--- nbones:%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="840"/>
        <source>Cannot import mesh %2:
%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="858"/>
        <source>%1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_ImpExp.cpp" line="865"/>
        <source>Imported %1 rigged mesh%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="9"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="22"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="36"/>
        <source>&amp;Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="55"/>
        <source>Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="68"/>
        <source>Navigate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="74"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="77"/>
        <source>&amp;Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="78"/>
        <source>On import meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="80"/>
        <source>On assemble vertex animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="118"/>
        <source>merge vertices and pos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="120"/>
        <source>recompute normals and merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="122"/>
        <source>do nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="135"/>
        <source>trust vertex order to be the same</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="136"/>
        <source>Use this option if you feel lucky and hope that vertex order was preserved between the frames.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="138"/>
        <source>trust texture coordinates to be unique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="140"/>
        <source>Use this option if you think that each vertex can be identified uniquely by its texture coords (best option)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="142"/>
        <source>quiver mode - start with max arrows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="143"/>
        <source>When you add a frame: what is not in the exact same position as the 1st frame disappears</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="161"/>
        <source>Auto zoom-and-recenter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="162"/>
        <source>according to selected object(s) only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="164"/>
        <source>according to all objects in file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="172"/>
        <source>Mesh rendering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="176"/>
        <source>always use default settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="173"/>
        <source>infer settings from Material flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="174"/>
        <source>E.g. alpha-transparency will depend on Material flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="177"/>
        <source>Never use alpha transparency, regardless of Material flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="198"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="199"/>
        <source>System default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="207"/>
        <source>Test a custom translation file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="224"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="226"/>
        <source>Create a new file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="229"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="231"/>
        <source>Open an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="234"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="236"/>
        <source>Save the document to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="239"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="240"/>
        <source>Cut currently selected objects.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="242"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="243"/>
        <source>Copy currently selected objects in the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="244"/>
        <source>Add to Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="245"/>
        <source>Add currently selected objects to clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="247"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="248"/>
        <source>Paste objects from the clipboard into currect BRF.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="252"/>
        <source>Cut frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="254"/>
        <source>Cut current frame of a vertex animated mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="255"/>
        <source>Copy frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="257"/>
        <source>Copy current frame of a vertex animated mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="258"/>
        <source>Paste frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="261"/>
        <source>Paste frame from clipboard as next frame in the current vertex animated mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="262"/>
        <source>Paste rigging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="263"/>
        <source>Make a rigging for current mesh(-es) similar to one of the meshes in the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="266"/>
        <source>Paste modifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="267"/>
        <source>Move vertices of current mesh according to a 2 frame mesh animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="270"/>
        <source>Paste timings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="271"/>
        <source>Paste timings of vertex or skeletal animation in clipboard into other animation(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="286"/>
        <source>Save &amp;As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="288"/>
        <source>Save the document under a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="298"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="299"/>
        <source>Alt+F4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="300"/>
        <source>Exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="303"/>
        <source>Why the checkerboard pattern?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="304"/>
        <source>Diagnose why I&apos;m seeing a checkboard pattern instead of my texture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="309"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="310"/>
        <source>F1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="311"/>
        <source>About OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="314"/>
        <source>_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="318"/>
        <source>Sort entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="319"/>
        <source>Sort current entries alphabetically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="322"/>
        <source>Static mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="323"/>
        <source>Import a static Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="324"/>
        <source>Rigged mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="325"/>
        <source>Import rigged (skeletal animable) Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="326"/>
        <source>Frame of vertex-animated mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="327"/>
        <source>Import a static mesh and add it as a vertex-animation frame of current Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="328"/>
        <source>Vertex-animated mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="329"/>
        <source>Import a vertex animated mesh from a MD3 file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="330"/>
        <location filename="../main_info.cpp" line="13"/>
        <source>Skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="331"/>
        <source>Import a Skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="335"/>
        <source>Skeletal animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="336"/>
        <source>Import a skeletal Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="337"/>
        <source>Collision body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="338"/>
        <source>Import an (multi-object) OBJ mesh as a Collision object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="339"/>
        <source>Anything from a BRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="340"/>
        <source>Import all content form another BRF file into current one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="341"/>
        <source>New Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="342"/>
        <source>Make a new Material object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="343"/>
        <source>New Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="344"/>
        <source>Make a new Texture object from a dds texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="345"/>
        <source>New Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="346"/>
        <source>Enlist a new Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="348"/>
        <source>New Menu Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="349"/>
        <source>Add a Menu Background (Mesh, Material, and Texture)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="352"/>
        <source>follow link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="353"/>
        <source>ctrl+right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="354"/>
        <source>Go from a mesh to used material; go from a material to used textures/shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="356"/>
        <source>follow back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="357"/>
        <source>ctrl+left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="358"/>
        <source>Go back to the mesh (from a material) or material (from texture or shaders).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="359"/>
        <source>next back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="360"/>
        <source>prev back-link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="361"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="362"/>
        <location filename="../main_create.cpp" line="377"/>
        <source>ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="363"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="364"/>
        <source>Reload ini files, brf files inside it, and dds textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="365"/>
        <source>F5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="366"/>
        <source>Scan module for usages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="367"/>
        <source>Scans module content and txt files, to compute what uses what</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="368"/>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="369"/>
        <source>Change current Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="370"/>
        <source>Choose the current module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="372"/>
        <source>Scan module for errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="373"/>
        <source>ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="374"/>
        <source>Scan module.ini and included brf files for inconsistencies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="376"/>
        <source>Find in module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="378"/>
        <source>Look for an object in all brf listed inside current module.ini.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="380"/>
        <source>Select a BRF in module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="381"/>
        <source>Select a BRF file of this module.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="382"/>
        <source>F7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="383"/>
        <source>Show unreferenced texture files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="384"/>
        <source>Show texture files non referenced in any brf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="387"/>
        <source>Show module stats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="388"/>
        <source>Show statistics for current Module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="405"/>
        <source>Register BRF extension</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="406"/>
        <source>Make so that clicking on a brf file opens OpenBRF.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="419"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="420"/>
        <source>Default mode: rotate objects with mouse, zoom in/out with wheel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="421"/>
        <source>helmet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="422"/>
        <source>Helmet mode: for objects with vertical Z axis, like M&amp;B helmets or weapons.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="423"/>
        <source>scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="424"/>
        <source>Scene mode: navigate with mouse and WASD (levitate with wheel, zoom with shift)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="435"/>
        <source>combo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="436"/>
        <source>See objects combined, when selecting multiple things</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="437"/>
        <source>aside</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="438"/>
        <source>See object side-to-side, when selecting multiple things</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="440"/>
        <source>mult-view:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_create.cpp" line="458"/>
        <source>view-mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="9"/>
        <source>Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="10"/>
        <source>Texture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="11"/>
        <source>Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="12"/>
        <source>Material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="14"/>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="15"/>
        <source>Collision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="16"/>
        <location filename="../main_info.cpp" line="29"/>
        <source>???</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="22"/>
        <source>Meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="23"/>
        <source>Textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="24"/>
        <source>Shaders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="25"/>
        <source>Materials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="26"/>
        <source>Skeletons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="27"/>
        <source>Animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="28"/>
        <source>Collisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="49"/>
        <source>&lt;p&gt;&amp;nbsp; &amp;nbsp; &lt;b&gt;OpenBrf&lt;/b&gt;&lt;br&gt;&amp;nbsp; &amp;nbsp; by &lt;b&gt;%2&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&amp;nbsp; &amp;nbsp; &lt;b&gt;ver %6&lt;/b&gt;&lt;br&gt;&amp;nbsp; &amp;nbsp; (%1)&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;i&gt;Testing, bug reporting, suggestions by:&lt;/i&gt; %3&lt;/p&gt;&lt;p&gt;&lt;i&gt;Additional art by:&lt;/i&gt; %4&lt;/p&gt;&lt;p&gt;&lt;i&gt;Translations by:&lt;/i&gt; %5&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="72"/>
        <source>additional code and Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="139"/>
        <source>Open-Brf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="84"/>
        <source>&lt;b&gt;What is this autofix DXT texture option?&lt;/b&gt;&lt;br&gt;&lt;p&gt;Many DDS texture creation programs/plugins around will output DXT1 textures with a minor error in the header.&lt;/p&gt;&lt;p&gt;This error confuses me (OpenBRF) but not Mount and Blade (or many other programs).&lt;/p&gt;&lt;p&gt;(When I cannot read a texture for this or any other problem, I display a chekerboard pattern instead).&lt;/p&gt;&lt;p&gt;If you want, I can silently fix this error every time I encounter it (I&apos;ll shamelessly write on the texture dss files on disk).&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="104"/>
        <source>I don&apos;t know what the material &lt;i&gt;&quot;%1&quot;&lt;/i&gt; is.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="105"/>
        <source>I&apos;ve scanned in all file &quot;%1&quot; and didn&apos;t find a &lt;i&gt;load_mod_resource&lt;/i&gt; or &lt;i&gt;load_resource&lt;/i&gt; command that pointed me to a brf file that contained any such material</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="108"/>
        <source>&lt;br&gt;- double check material name of the mesh&lt;br&gt;&lt;b&gt;or&lt;/b&gt;&lt;br&gt;- find the brf-file with the material, or create one&lt;br&gt;- add a line &lt;i&gt;load_&lt;b&gt;mod&lt;/b&gt;_resource&lt;/i&gt; in module.ini, with a text editor,&lt;br&gt;- (note the &lt;i&gt;mod&lt;/i&gt; part)!&lt;br&gt;- save module.ini&lt;br&gt;- come back, and refresh Module [f5]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="118"/>
        <source>I cannot find the file &quot;%1&quot; on disk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="119"/>
        <source>I&apos;ve looked in folders &lt;br&gt;%1&lt;br&gt; and &lt;br&gt;%2&lt;br&gt; and &lt;br&gt;%3&lt;br&gt; but it wasn&apos;t there...&lt;br&gt;Maybe it is was tiff texture? (I don&apos;t understand them).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="122"/>
        <source>&lt;br&gt;- double check DiffuesA texture name of the material&lt;br&gt;- (hint: remember you can navigate with ctrl-left/right)&lt;br&gt;&lt;b&gt;or&lt;/b&gt;&lt;br&gt;- make sure the missing texture file in mod texture folder!&lt;br&gt;- put it there if it is missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="131"/>
        <source>I cannot understand the texture format of  file &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="132"/>
        <source>I&apos;m supposed to understand .dds textures of formats DXT1 (maybe), DXT3, and DXT5.&lt;br&gt;But some kinds of DXT1 texture confuse me, and too big textures too.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="135"/>
        <source>Maybe just accept the fact... it should still show the texture in game.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main_info.cpp" line="140"/>
        <source>&lt;i&gt;I could not display the real texture because:&lt;/i&gt;&lt;br&gt;&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;&lt;br&gt;%2&lt;br&gt;&lt;br&gt;&lt;b&gt;Cure: &lt;/b&gt;%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="39"/>
        <location filename="../mainwindow.cpp" line="1287"/>
        <location filename="../mainwindow.cpp" line="1297"/>
        <location filename="../mainwindow.cpp" line="1558"/>
        <source>OpenBrf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="40"/>
        <source>%1 been modified.
Save changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="41"/>
        <source>Internal reference objects have</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="41"/>
        <source>The dataset has</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Set %1 mesh materials to &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="317"/>
        <source>Set time of frame %1 to %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="331"/>
        <location filename="../mainwindow.cpp" line="369"/>
        <source>CAnnot find skel_human, skel_dwarf and skel_orc in reference data.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="405"/>
        <source>Invalid frame %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="414"/>
        <source>%1 meshes shrunk around bones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="426"/>
        <source>Cannot find skel_human, skel_dwarf and skel_orc in reference data.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="572"/>
        <source>Set flag(s) to &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="641"/>
        <source>Stop editing reference data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="642"/>
        <source>Stop editing &quot;reference&quot; skeletons, animations &amp; meshes, that OpenBrf uses to display data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="644"/>
        <source>Edit reference data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="645"/>
        <source>Edit &quot;reference&quot; skeletons, animations &amp; meshes, that OpenBrf uses to display data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="765"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="766"/>
        <source>New %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="767"/>
        <source>new_%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="836"/>
        <source>Oops... no skin is currently available...
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="841"/>
        <source>Skin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="845"/>
        <source>Select a skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="846"/>
        <source>Select a skin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="889"/>
        <source>Vertex unified.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="905"/>
        <source>Cannot merge these meshes
 (different number of frames,
 or rigged VS not rigged).
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="972"/>
        <source>Normals recomputed with %1% hard edges.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1057"/>
        <source>Shift animation timings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1058"/>
        <source>Current Interval: [%1 %2]
New interval: [%1+k %2+k]

Select k:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1135"/>
        <source>Transfer Rigging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1136"/>
        <source>Transfer rigging:
select a rigged mesh first,
then all target meshes.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1163"/>
        <source>Same skeleton:
reskeletonization canceled.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1170"/>
        <source>Different number of bones:
reskeletonization canceled.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1288"/>
        <source>Renaming %1...
new name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1298"/>
        <source>%3 common prefix for %1 %2...
new prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1298"/>
        <source>Changing the</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1298"/>
        <source>Adding a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1398"/>
        <source>Copy Rigging into another mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1399"/>
        <source>Copy Rigging into another mesh:
- select one or more sample rigged mesh first,
- copy them (ctrl-C)
- then select one or more target meshes (rigged or otherwise),
- then paste rigging.

(works best if sample mesh is similar to target meshes)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1436"/>
        <source>Vertex number mismatch... using texture-coord matching instead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1523"/>
        <source>Cannot paste timings! Select *one* animated mesh or skel animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1536"/>
        <source>Pasted timings over %1 (animated) mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1542"/>
        <source>Pasted timings over %1 skeletal animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1545"/>
        <source>Cannot paste times over that</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1558"/>
        <source>To use paste modification mesh: firstcopy a 2 frames mesh. Then, select one or more destination meshes, and &quot;paste modification&quot;any vertex in any frame of the destination mesh that are in the same pos of frame 0,will be moved on the position of frame 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1693"/>
        <location filename="../mainwindow.cpp" line="1732"/>
        <source>Canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1715"/>
        <source>Mounted %1 mesh%2 on bone %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1749"/>
        <source>Added mesh %1 to set %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1768"/>
        <source>Animation %2 split in %1 chunks!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1770"/>
        <source>Animation could be auto-split (frames are too conescutive)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1777"/>
        <source>Select an &quot;actions.txt&quot; file (hint: it&apos;s in the module dir)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1778"/>
        <source>%1\actions.txt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1779"/>
        <source>Txt file(*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1782"/>
        <source>Split canceled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1789"/>
        <source>Nothing to split (or could not split).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1796"/>
        <source>Animation %2 split in %1 chunks -- new animation.txt file save in &quot;%3&quot;!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1989"/>
        <source>Cannot save reference file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2020"/>
        <source>Editing reference file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2037"/>
        <source>Cannot load %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2064"/>
        <source>You are saving a CommonRes file!
(i.e. not one specific of this module).

Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2070"/>
        <source>Cannot write file %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2073"/>
        <source>File saved!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2194"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2196"/>
        <source>Resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2213"/>
        <source>Reference file saved!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2223"/>
        <source>M&amp;B Resource (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2223"/>
        <source>WarBand Resource v.1 (*.brf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2226"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2247"/>
        <source> [not in module.ini]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2251"/>
        <source>%1%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2253"/>
        <source>%1 - %2%3%4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2255"/>
        <source>%1 - editing internal reference data%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2326"/>
        <source>%5 %1 brf files from module.ini of &quot;%3&quot;-- %2 msec total [%4 text/mat/shad]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2328"/>
        <source>scanned</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2328"/>
        <source>ERRORS found while scanning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2439"/>
        <source>Navigate: cannot find material &quot;%1&quot; in current module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2482"/>
        <source>Navigate: cannot find %2 &quot;%1&quot; in current module</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2495"/>
        <source>Navigate right: pos = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2658"/>
        <source>&amp;%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2739"/>
        <source>Material flags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTextBrowser</name>
    <message>
        <location filename="../iniData.cpp" line="625"/>
        <source>%6 &lt;a href=&quot;#%1.%2.%3&quot;&gt;%4&lt;/a&gt; (in %5)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Selector</name>
    <message>
        <location filename="../selector.cpp" line="10"/>
        <source>&amp;Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="11"/>
        <source>Te&amp;xture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="12"/>
        <source>&amp;Shader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="13"/>
        <source>Mat&amp;erial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="14"/>
        <source>S&amp;keleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="15"/>
        <source>&amp;Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="16"/>
        <source>&amp;Collision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="42"/>
        <source>Split via action.txt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="43"/>
        <source>Split sequence following the action.txt file. A new &quot;action [after split].txt&quot; file is also produced, which use the new animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="45"/>
        <source>Auto-split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="46"/>
        <source>Auto-split sequence into its separated chunks, separating it at lasge gaps in frames.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="48"/>
        <location filename="../selector.cpp" line="430"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="52"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="56"/>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="58"/>
        <source>next tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="62"/>
        <source>left tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="66"/>
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="68"/>
        <source>Move this object upward in the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="71"/>
        <source>Move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="73"/>
        <source>Move this object one step down in the list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="76"/>
        <source>Add to reference animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="77"/>
        <source>Add this animation to reference animations (to use it later to display rigged meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="79"/>
        <source>Add to reference skeletons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="80"/>
        <source>Add this animation to reference skeletons (to use it later for animations).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="83"/>
        <source>set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="84"/>
        <source>Add this mesh to reference skins (to use it later to display animations).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="109"/>
        <source>&lt;none&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="114"/>
        <source>mod file &lt;%1&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="116"/>
        <source>mod file &lt;%1&gt; (indirectly)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="120"/>
        <source>&lt;no .txt file&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="122"/>
        <source>&lt;core engine&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="124"/>
        <source>&lt;core engine&gt; (indirectly)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="127"/>
        <source>&lt;not in module.ini&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="130"/>
        <source>(not computed: compute now)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="134"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="136"/>
        <source>Info on mesh import/export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="138"/>
        <source>Export static mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="139"/>
        <source>Export this model (or this frame) as a 3D static mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="141"/>
        <source>Export vertex ani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="142"/>
        <source>Export this model as a mesh with vertex animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="144"/>
        <source>Export combined mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="145"/>
        <source>Export this group of models in a single OBJ.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="146"/>
        <source>Export all meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="147"/>
        <source>Export each of these models as separate OBJs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="149"/>
        <source>Export rigged mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="150"/>
        <source>Export this model (or this frame) as a rigged mesh.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="152"/>
        <source>Export (nude) skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="153"/>
        <source>Export this skeleton (as a set of nude bones).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="154"/>
        <source>Export skeleton with skin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="155"/>
        <source>Export this skeleton (as a rigged skin).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="156"/>
        <source>Export a skin for this ani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="157"/>
        <source>Export a rigged skin which can be used for this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="159"/>
        <source>Export animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="160"/>
        <source>Export this animation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="162"/>
        <source>Reskeletonize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="163"/>
        <source>Adapt this rigged mesh to a new skeleton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="165"/>
        <source>Transfer rigging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="166"/>
        <source>Copy rigging from one mesh to another</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="169"/>
        <source>Mirror</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="170"/>
        <source>Mirror this object on the X axis.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="172"/>
        <source>Roto-translate-rescale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="173"/>
        <source>Apply a gemoetric transform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="175"/>
        <source>Rescale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="176"/>
        <source>Rescale this object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="178"/>
        <source>Shift time interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="179"/>
        <source>Shift a time interval for this animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="181"/>
        <source>Make quad-dominant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="182"/>
        <source>Try to merge most triangles into fewer quads (more efficient!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="183"/>
        <source>Combine collision objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="184"/>
        <source>Make a combined collision obj. unifying these objs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="186"/>
        <source>Recompute normals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="187"/>
        <source>Recompute normals for this model, and unify pos and vertices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="189"/>
        <source>Unify vertices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="190"/>
        <source>Unify identical vertices and pos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="192"/>
        <source>Combine meshes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="193"/>
        <source>Make a combined mesh unifying these meshes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="195"/>
        <source>Mount on one bone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="196"/>
        <source>Put this mesh on top of a single skeleton bone.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="198"/>
        <source>remove all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="199"/>
        <source>Remove all faces that are backfacing (e.g. in beard meshes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="200"/>
        <source>add (x2 faces)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="201"/>
        <source>Duplicate all faces: for each current face, add a backfacing face.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="204"/>
        <source>per-vertex color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="205"/>
        <source>rigging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="206"/>
        <source>vertex animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="207"/>
        <source>Discard vertex animation (keeps only current frame)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="211"/>
        <source>Make a skeleton-modification mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="212"/>
        <source>Modify from a skeleton-modification mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="281"/>
        <source>[Right-Click]: tools for %1. Multiple selections with [Shift]-[Ctrl].</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="284"/>
        <source>[Right-Click]: tools for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="430"/>
        <source>Group rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="442"/>
        <source>Used by...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="525"/>
        <source>Backfacing faces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="529"/>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="561"/>
        <source>Add to reference skins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="564"/>
        <source>to Skin Set %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selector.cpp" line="568"/>
        <source>to Skin Set %1 [new set]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TableModel</name>
    <message>
        <location filename="../tablemodel.cpp" line="73"/>
        <source>HEADER</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextFile</name>
    <message>
        <location filename="../iniData.cpp" line="126"/>
        <source>cannot open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="134"/>
        <source>expected &apos;%1&apos;,
got &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="138"/>
        <source>unexpected end of file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="168"/>
        <source>cannot read token n. %1 from:
 &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="175"/>
        <location filename="../iniData.cpp" line="183"/>
        <source>expected number istead of &apos;%1&apos; (token %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="176"/>
        <source>wrong number : %1 (not in [%2, %3]) (token %4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../iniData.cpp" line="193"/>
        <source>Error reading file &apos;%1&apos;,
at line %3:
%2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>askModErrorDialog</name>
    <message>
        <location filename="../askModErrorDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.ui" line="45"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askModErrorDialog.ui" line="81"/>
        <source>look in commonres too</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>askTexturenameDialog</name>
    <message>
        <location filename="../askTexturenameDialog.ui" line="14"/>
        <source>OpenBRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.ui" line="52"/>
        <source>name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.ui" line="68"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askTexturenameDialog.ui" line="81"/>
        <source>also add a new Texture</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
