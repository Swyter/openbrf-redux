#ifndef MYSELECTIONMODEL_H
#define MYSELECTIONMODEL_H

#include <QItemSelectionModel>

class MySelectionModel : public QItemSelectionModel
{
	Q_OBJECT
public:
	//explicit MySelectionModel(QObject *parent = 0);
	
signals:
	
public slots:
	
};

#endif // MYSELECTIONMODEL_H
