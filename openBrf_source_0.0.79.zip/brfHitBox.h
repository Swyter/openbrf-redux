/* OpenBRF -- by marco tarini. Provided under GNU General Public License */
#ifndef BRFHITBOX_H
#define BRFHITBOX_H

/*
#include <map>
#include <string>

class BrfHitBox{
public:
    std::map<std::string, BrfBody> data; // hit box per bone
    BrfBody* find(const char* name);
    void clear();
};

class BrfHitBoxSet {
public:
  std::map<std::string, BrfHitBox> data;
  bool load(const wchar_t*filename);

  BrfHitBox* find(const char* name);
  void clear();
};
*/

#endif // BRFHITBOX_H
